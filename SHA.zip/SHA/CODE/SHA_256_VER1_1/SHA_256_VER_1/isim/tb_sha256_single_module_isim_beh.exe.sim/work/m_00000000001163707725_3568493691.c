/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/SHA/CODE/SHA_256_VER1_1/SHA_256_VER_1/tb_sha256_single_module.v";
static const char *ng1 = "sha256_single_module_waveform.vcd";
static int ng2[] = {0, 0};
static unsigned int ng3[] = {1U, 0U};
static int ng4[] = {1229212741, 0, 0, 0};
static unsigned int ng5[] = {2U, 0U};
static int ng6[] = {1229867348, 0, 0, 0};
static unsigned int ng7[] = {4U, 0U};
static int ng8[] = {1380275027, 0, 1129270608, 0};
static unsigned int ng9[] = {8U, 0U};
static int ng10[] = {1313428296, 0, 17993, 0};
static int ng11[] = {1313822542, 0, 5590603, 0};
static const char *ng12 = "[%0t ns] State: %s, Block: %d, Round: %2d, Done: %b";
static const char *ng13 = "======================================================";
static const char *ng14 = "= B?t d?u Testbench d\343 c?i ti?n cho N=1 kh?i        =";
static int ng15[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
static int ng16[] = {1, 0};
static const char *ng17 = "[%0t ns] DUT d\343 s?n s\340ng trong tr?ng th\341i IDLE.";
static const char *ng18 = "[%0t ns] N?p tru?c d? li?u v\340 s? kh?i N.";
static unsigned int ng19[] = {24U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 1633837952U, 0U};
static const char *ng20 = "[%0t ns] K\355ch ho?t i_write d? b?t d?u x? l\375 KH?I 1.";
static const char *ng21 = "[%0t ns] \320ang d?i o_done...";
static const char *ng22 = "[%0t ns] To\340n b? qu\341 tr\354nh bam ho\340n t?t!";
static const char *ng23 = "-----------------------------------------------";
static const char *ng24 = "K?T QU? MONG \320?I : %h";
static unsigned int ng25[] = {4060091821U, 0U, 3021012833U, 0U, 2518121116U, 0U, 2953011619U, 0U, 1571693091U, 0U, 1094795486U, 0U, 2399260650U, 0U, 3128432319U, 0U};
static const char *ng26 = "K?T QU? TH?C T?  : %h";
static const char *ng27 = "****** TEST PASSED! ******";
static const char *ng28 = "****** TEST FAILED! ******";



static void Always_36_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 4280U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 4088);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);
    t4 = (t0 + 2560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB10;

LAB9:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 2560);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

LAB10:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB9;

}

static void Initial_39_1(char *t0)
{
    char *t1;

LAB0:    xsi_set_current_line(39, ng0);

LAB2:    xsi_set_current_line(40, ng0);
    xsi_vcd_dumpfile(ng1);
    xsi_set_current_line(41, ng0);
    t1 = ((char*)((ng2)));
    xsi_vcd_dumpvars_args(*((unsigned int *)t1), t0, (char)109, t0, (char)101);

LAB1:    return;
}

static void Always_46_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 4776U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 5592);
    *((int *)t2) = 1;
    t3 = (t0 + 4808);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(46, ng0);

LAB5:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 7992);
    t5 = *((char **)t4);
    t6 = ((((char*)(t5))) + 56U);
    t7 = *((char **)t6);

LAB6:    t8 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t8, 4);
    if (t9 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t2, 4);
    if (t9 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t2, 4);
    if (t9 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng9)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t2, 4);
    if (t9 == 1)
        goto LAB13;

LAB14:
LAB16:
LAB15:    xsi_set_current_line(52, ng0);
    t2 = ((char*)((ng11)));
    t3 = (t0 + 3360);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);

LAB17:    goto LAB2;

LAB7:    xsi_set_current_line(48, ng0);
    t10 = ((char*)((ng4)));
    t11 = (t0 + 3360);
    xsi_vlogvar_assign_value(t11, t10, 0, 0, 64);
    goto LAB17;

LAB9:    xsi_set_current_line(49, ng0);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 3360);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    goto LAB17;

LAB11:    xsi_set_current_line(50, ng0);
    t3 = ((char*)((ng8)));
    t4 = (t0 + 3360);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    goto LAB17;

LAB13:    xsi_set_current_line(51, ng0);
    t3 = ((char*)((ng10)));
    t4 = (t0 + 3360);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    goto LAB17;

}

static void Always_57_3(char *t0)
{
    char t13[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    t1 = (t0 + 5024U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 5608);
    *((int *)t2) = 1;
    t3 = (t0 + 5056);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(57, ng0);

LAB5:    xsi_set_current_line(58, ng0);
    t4 = (t0 + 2720);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB6;

LAB7:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(58, ng0);

LAB9:    xsi_set_current_line(59, ng0);
    t14 = xsi_vlog_time(t13, 1000.0000000000000, 1000.0000000000000);
    t15 = (t0 + 3360);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t0 + 8024);
    t19 = *((char **)t18);
    t20 = ((((char*)(t19))) + 56U);
    t21 = *((char **)t20);
    t22 = (t0 + 8056);
    t23 = *((char **)t22);
    t24 = ((((char*)(t23))) + 56U);
    t25 = *((char **)t24);
    t26 = (t0 + 2000U);
    t27 = *((char **)t26);
    xsi_vlogfile_write(1, 0, 0, ng12, 6, t0, (char)118, t13, 64, (char)118, t17, 64, (char)118, t21, 8, (char)118, t25, 6, (char)118, t27, 1);
    goto LAB8;

}

static void Initial_67_4(char *t0)
{
    char t7[8];
    char t32[16];
    char t33[64];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    t1 = (t0 + 5272U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(67, ng0);

LAB4:    xsi_set_current_line(68, ng0);
    xsi_vlogfile_write(1, 0, 0, ng13, 1, t0);
    xsi_set_current_line(69, ng0);
    xsi_vlogfile_write(1, 0, 0, ng14, 1, t0);
    xsi_set_current_line(70, ng0);
    xsi_vlogfile_write(1, 0, 0, ng13, 1, t0);
    xsi_set_current_line(73, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2560);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(73, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(73, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2880);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(73, ng0);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 3040);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 512, 0LL);
    xsi_set_current_line(73, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3200);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 5080);
    xsi_process_wait(t2, 50000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(75, ng0);
    t2 = ((char*)((ng16)));
    t3 = (t0 + 2720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(78, ng0);

LAB6:    t2 = (t0 + 8080);
    t3 = *((char **)t2);
    t4 = ((((char*)(t3))) + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng3)));
    memset(t7, 0, 8);
    t8 = (t5 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t8);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = (t12 | t15);
    t17 = *((unsigned int *)t8);
    t18 = *((unsigned int *)t9);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB10;

LAB7:    if (t19 != 0)
        goto LAB9;

LAB8:    *((unsigned int *)t7) = 1;

LAB10:    t23 = (t7 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB12;

LAB11:    t29 = (t0 + 5624);
    *((int *)t29) = 1;
    t30 = (t0 + 5272U);
    *((char **)t30) = &&LAB6;
    goto LAB1;

LAB9:    t22 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB10;

LAB12:    t31 = (t0 + 5624);
    *((int *)t31) = 0;
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 5640);
    *((int *)t2) = 1;
    t3 = (t0 + 5304);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(80, ng0);
    t2 = xsi_vlog_time(t32, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng17, 2, t0, (char)118, t32, 64);
    xsi_set_current_line(83, ng0);
    t2 = xsi_vlog_time(t32, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng18, 2, t0, (char)118, t32, 64);
    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng16)));
    t3 = (t0 + 3200);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(85, ng0);
    t2 = ((char*)((ng19)));
    t3 = (t0 + 3040);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 512, 0LL);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 5656);
    *((int *)t2) = 1;
    t3 = (t0 + 5304);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(91, ng0);
    t2 = xsi_vlog_time(t32, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng20, 2, t0, (char)118, t32, 64);
    xsi_set_current_line(92, ng0);
    t2 = ((char*)((ng16)));
    t3 = (t0 + 2880);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 5672);
    *((int *)t2) = 1;
    t3 = (t0 + 5304);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB15:    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2880);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(97, ng0);
    t2 = xsi_vlog_time(t32, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng21, 2, t0, (char)118, t32, 64);
    xsi_set_current_line(98, ng0);

LAB16:    t2 = (t0 + 2000U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng16)));
    memset(t7, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t10 = *((unsigned int *)t3);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t5);
    t15 = (t13 ^ t14);
    t16 = (t12 | t15);
    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t5);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB20;

LAB17:    if (t19 != 0)
        goto LAB19;

LAB18:    *((unsigned int *)t7) = 1;

LAB20:    t8 = (t7 + 4);
    t24 = *((unsigned int *)t8);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB22;

LAB21:    t9 = (t0 + 5688);
    *((int *)t9) = 1;
    t22 = (t0 + 5272U);
    *((char **)t22) = &&LAB16;
    goto LAB1;

LAB19:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB20;

LAB22:    t23 = (t0 + 5688);
    *((int *)t23) = 0;
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 5704);
    *((int *)t2) = 1;
    t3 = (t0 + 5304);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB23:    xsi_set_current_line(100, ng0);
    t2 = xsi_vlog_time(t32, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng22, 2, t0, (char)118, t32, 64);
    xsi_set_current_line(103, ng0);
    xsi_vlogfile_write(1, 0, 0, ng23, 1, t0);
    xsi_set_current_line(104, ng0);
    t2 = ((char*)((ng25)));
    xsi_vlogfile_write(1, 0, 0, ng24, 2, t0, (char)118, t2, 256);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 2160U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng26, 2, t0, (char)118, t3, 256);
    xsi_set_current_line(106, ng0);
    xsi_vlogfile_write(1, 0, 0, ng23, 1, t0);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 2160U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng25)));
    xsi_vlog_unsigned_equal(t33, 256, t3, 256, t2, 256);
    t4 = (t33 + 4);
    t10 = *((unsigned int *)t4);
    t11 = (~(t10));
    t12 = *((unsigned int *)t33);
    t13 = (t12 & t11);
    t14 = (t13 != 0);
    if (t14 > 0)
        goto LAB24;

LAB25:    xsi_set_current_line(110, ng0);

LAB28:    xsi_set_current_line(111, ng0);
    xsi_vlogfile_write(1, 0, 0, ng28, 1, t0);

LAB26:    xsi_set_current_line(114, ng0);
    t2 = (t0 + 5080);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB29;
    goto LAB1;

LAB24:    xsi_set_current_line(108, ng0);

LAB27:    xsi_set_current_line(109, ng0);
    xsi_vlogfile_write(1, 0, 0, ng27, 1, t0);
    goto LAB26;

LAB29:    xsi_set_current_line(115, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}


extern void work_m_00000000001163707725_3568493691_init()
{
	static char *pe[] = {(void *)Always_36_0,(void *)Initial_39_1,(void *)Always_46_2,(void *)Always_57_3,(void *)Initial_67_4};
	xsi_register_didat("work_m_00000000001163707725_3568493691", "isim/tb_sha256_single_module_isim_beh.exe.sim/work/m_00000000001163707725_3568493691.didat");
	xsi_register_executes(pe);
}
