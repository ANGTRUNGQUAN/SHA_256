/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/SHA/CODE/SHA_COMBINATION/SHA_COMBINATION/tb_sha256_comb_logic.v";
static const char *ng1 = "==== SHA256 Combination Logic Test with 'abc' message ====";
static unsigned int ng2[] = {1779033703U, 0U};
static unsigned int ng3[] = {3144134277U, 0U};
static unsigned int ng4[] = {1013904242U, 0U};
static unsigned int ng5[] = {2773480762U, 0U};
static unsigned int ng6[] = {1359893119U, 0U};
static unsigned int ng7[] = {2600822924U, 0U};
static unsigned int ng8[] = {528734635U, 0U};
static unsigned int ng9[] = {1541459225U, 0U};
static unsigned int ng10[] = {24U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 1633837952U, 0U};
static int ng11[] = {0, 0};
static int ng12[] = {20, 0};
static const char *ng13 = "---- Round %0d ----";
static const char *ng14 = "W[%0d] = %h";
static const char *ng15 = "K[%0d] = %h";
static const char *ng16 = "T1     = %h";
static const char *ng17 = "T2     = %h";
static const char *ng18 = "a_out  = %h";
static const char *ng19 = "b_out  = %h";
static const char *ng20 = "c_out  = %h";
static const char *ng21 = "d_out  = %h";
static const char *ng22 = "e_out  = %h";
static const char *ng23 = "f_out  = %h";
static const char *ng24 = "g_out  = %h";
static const char *ng25 = "h_out  = %h";
static const char *ng26 = "";
static int ng27[] = {1, 0};
static const char *ng28 = "==== TEST DONE ====";



static void Initial_29_0(char *t0)
{
    char t6[8];
    char t13[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;

LAB0:    t1 = (t0 + 5864U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(29, ng0);

LAB4:    xsi_set_current_line(30, ng0);
    xsi_vlogfile_write(1, 0, 0, ng1, 1, t0);
    xsi_set_current_line(35, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3344);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(36, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3504);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3664);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 3824);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(39, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 3984);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(40, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 4144);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 4304);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 4464);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(47, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 4784);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 512);
    xsi_set_current_line(57, ng0);
    xsi_set_current_line(57, ng0);
    t2 = ((char*)((ng11)));
    t3 = (t0 + 4944);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB5:    t2 = (t0 + 4944);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng12)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(76, ng0);
    xsi_vlogfile_write(1, 0, 0, ng28, 1, t0);
    xsi_set_current_line(77, ng0);
    xsi_vlog_finish(1);

LAB1:    return;
LAB6:    xsi_set_current_line(57, ng0);

LAB8:    xsi_set_current_line(58, ng0);
    t14 = (t0 + 4944);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t13, 0, 8);
    t17 = (t13 + 4);
    t18 = (t16 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (t19 >> 0);
    *((unsigned int *)t13) = t20;
    t21 = *((unsigned int *)t18);
    t22 = (t21 >> 0);
    *((unsigned int *)t17) = t22;
    t23 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t23 & 63U);
    t24 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t24 & 63U);
    t25 = (t0 + 4624);
    xsi_vlogvar_assign_value(t25, t13, 0, 0, 6);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 5672);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 4944);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    xsi_vlogfile_write(1, 0, 0, ng13, 2, t0, (char)119, t4, 32);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 4944);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2784U);
    t7 = *((char **)t5);
    xsi_vlogfile_write(1, 0, 0, ng14, 3, t0, (char)119, t4, 32, (char)118, t7, 32);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 4944);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2944U);
    t7 = *((char **)t5);
    xsi_vlogfile_write(1, 0, 0, ng15, 3, t0, (char)119, t4, 32, (char)118, t7, 32);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 2464U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng16, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2624U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng17, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(65, ng0);
    t2 = (t0 + 1184U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng18, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 1344U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng19, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1504U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng20, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 1664U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng21, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 1824U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng22, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 1984U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng23, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2144U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng24, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 2304U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng25, 2, t0, (char)118, t3, 32);
    xsi_set_current_line(73, ng0);
    xsi_vlogfile_write(1, 0, 0, ng26, 1, t0);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 4944);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng27)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 4944);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB5;

}


extern void work_m_00000000000092814449_4271638374_init()
{
	static char *pe[] = {(void *)Initial_29_0};
	xsi_register_didat("work_m_00000000000092814449_4271638374", "isim/tb_sha256_comb_full_isim_beh.exe.sim/work/m_00000000000092814449_4271638374.didat");
	xsi_register_executes(pe);
}
