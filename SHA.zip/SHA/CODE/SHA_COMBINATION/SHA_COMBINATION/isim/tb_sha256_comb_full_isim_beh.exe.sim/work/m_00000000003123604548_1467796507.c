/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "x";
static const char *ng1 = "S0_func";
static const char *ng2 = "S1_func";
static const char *ng3 = "y";
static const char *ng4 = "z";
static const char *ng5 = "Ch_func";
static const char *ng6 = "Maj_func";
static const char *ng7 = "N";
static const char *ng8 = "ROTR";
static const char *ng9 = "sigma0_func";
static const char *ng10 = "sigma1_func";
static const char *ng11 = "D:/SHA/CODE/SHA_COMBINATION/SHA_COMBINATION/sha256_comb_logic.v";
static int ng12[] = {2, 0};
static int ng13[] = {30, 0};
static int ng14[] = {13, 0};
static int ng15[] = {19, 0};
static int ng16[] = {22, 0};
static int ng17[] = {10, 0};
static int ng18[] = {6, 0};
static int ng19[] = {26, 0};
static int ng20[] = {11, 0};
static int ng21[] = {21, 0};
static int ng22[] = {25, 0};
static int ng23[] = {7, 0};
static int ng24[] = {32, 0};
static int ng25[] = {18, 0};
static int ng26[] = {3, 0};
static int ng27[] = {17, 0};
static unsigned int ng28[] = {0U, 0U};
static unsigned int ng29[] = {1116352408U, 0U};
static unsigned int ng30[] = {1U, 0U};
static unsigned int ng31[] = {1899447441U, 0U};
static unsigned int ng32[] = {2U, 0U};
static unsigned int ng33[] = {3049323471U, 0U};
static unsigned int ng34[] = {3U, 0U};
static unsigned int ng35[] = {3921009573U, 0U};
static unsigned int ng36[] = {4U, 0U};
static unsigned int ng37[] = {961987163U, 0U};
static unsigned int ng38[] = {5U, 0U};
static unsigned int ng39[] = {1508970993U, 0U};
static unsigned int ng40[] = {6U, 0U};
static unsigned int ng41[] = {2453635748U, 0U};
static unsigned int ng42[] = {7U, 0U};
static unsigned int ng43[] = {2870763221U, 0U};
static unsigned int ng44[] = {8U, 0U};
static unsigned int ng45[] = {3624381080U, 0U};
static unsigned int ng46[] = {9U, 0U};
static unsigned int ng47[] = {310598401U, 0U};
static unsigned int ng48[] = {10U, 0U};
static unsigned int ng49[] = {607225278U, 0U};
static unsigned int ng50[] = {11U, 0U};
static unsigned int ng51[] = {1426881987U, 0U};
static unsigned int ng52[] = {12U, 0U};
static unsigned int ng53[] = {1925078388U, 0U};
static unsigned int ng54[] = {13U, 0U};
static unsigned int ng55[] = {2162078206U, 0U};
static unsigned int ng56[] = {14U, 0U};
static unsigned int ng57[] = {2614888103U, 0U};
static unsigned int ng58[] = {15U, 0U};
static unsigned int ng59[] = {3248222580U, 0U};
static unsigned int ng60[] = {16U, 0U};
static unsigned int ng61[] = {3835390401U, 0U};
static unsigned int ng62[] = {17U, 0U};
static unsigned int ng63[] = {4022224774U, 0U};
static unsigned int ng64[] = {18U, 0U};
static unsigned int ng65[] = {264347078U, 0U};
static unsigned int ng66[] = {19U, 0U};
static unsigned int ng67[] = {604807628U, 0U};
static unsigned int ng68[] = {20U, 0U};
static unsigned int ng69[] = {770255983U, 0U};
static unsigned int ng70[] = {21U, 0U};
static unsigned int ng71[] = {1249150122U, 0U};
static unsigned int ng72[] = {22U, 0U};
static unsigned int ng73[] = {1555081692U, 0U};
static unsigned int ng74[] = {23U, 0U};
static unsigned int ng75[] = {1996064986U, 0U};
static unsigned int ng76[] = {24U, 0U};
static unsigned int ng77[] = {2554220882U, 0U};
static unsigned int ng78[] = {25U, 0U};
static unsigned int ng79[] = {2821834349U, 0U};
static unsigned int ng80[] = {26U, 0U};
static unsigned int ng81[] = {2952996808U, 0U};
static unsigned int ng82[] = {27U, 0U};
static unsigned int ng83[] = {3210313671U, 0U};
static unsigned int ng84[] = {28U, 0U};
static unsigned int ng85[] = {3336571891U, 0U};
static unsigned int ng86[] = {29U, 0U};
static unsigned int ng87[] = {3584528711U, 0U};
static unsigned int ng88[] = {30U, 0U};
static unsigned int ng89[] = {113926993U, 0U};
static unsigned int ng90[] = {31U, 0U};
static unsigned int ng91[] = {338241895U, 0U};
static unsigned int ng92[] = {32U, 0U};
static unsigned int ng93[] = {666307205U, 0U};
static unsigned int ng94[] = {33U, 0U};
static unsigned int ng95[] = {773529912U, 0U};
static unsigned int ng96[] = {34U, 0U};
static unsigned int ng97[] = {1294757372U, 0U};
static unsigned int ng98[] = {35U, 0U};
static unsigned int ng99[] = {1396182291U, 0U};
static unsigned int ng100[] = {36U, 0U};
static unsigned int ng101[] = {1695183700U, 0U};
static unsigned int ng102[] = {37U, 0U};
static unsigned int ng103[] = {1986661051U, 0U};
static unsigned int ng104[] = {38U, 0U};
static unsigned int ng105[] = {2177026350U, 0U};
static unsigned int ng106[] = {39U, 0U};
static unsigned int ng107[] = {2456956037U, 0U};
static unsigned int ng108[] = {40U, 0U};
static unsigned int ng109[] = {2730485921U, 0U};
static unsigned int ng110[] = {41U, 0U};
static unsigned int ng111[] = {2820302411U, 0U};
static unsigned int ng112[] = {42U, 0U};
static unsigned int ng113[] = {3259730800U, 0U};
static unsigned int ng114[] = {43U, 0U};
static unsigned int ng115[] = {3345764771U, 0U};
static unsigned int ng116[] = {44U, 0U};
static unsigned int ng117[] = {3516065817U, 0U};
static unsigned int ng118[] = {45U, 0U};
static unsigned int ng119[] = {3600352804U, 0U};
static unsigned int ng120[] = {46U, 0U};
static unsigned int ng121[] = {4094571909U, 0U};
static unsigned int ng122[] = {47U, 0U};
static unsigned int ng123[] = {275423344U, 0U};
static unsigned int ng124[] = {48U, 0U};
static unsigned int ng125[] = {430227734U, 0U};
static unsigned int ng126[] = {49U, 0U};
static unsigned int ng127[] = {506948616U, 0U};
static unsigned int ng128[] = {50U, 0U};
static unsigned int ng129[] = {659060556U, 0U};
static unsigned int ng130[] = {51U, 0U};
static unsigned int ng131[] = {883997877U, 0U};
static unsigned int ng132[] = {52U, 0U};
static unsigned int ng133[] = {958139571U, 0U};
static unsigned int ng134[] = {53U, 0U};
static unsigned int ng135[] = {1322822218U, 0U};
static unsigned int ng136[] = {54U, 0U};
static unsigned int ng137[] = {1537002063U, 0U};
static unsigned int ng138[] = {55U, 0U};
static unsigned int ng139[] = {1747873779U, 0U};
static unsigned int ng140[] = {56U, 0U};
static unsigned int ng141[] = {1955562222U, 0U};
static unsigned int ng142[] = {57U, 0U};
static unsigned int ng143[] = {2024104815U, 0U};
static unsigned int ng144[] = {58U, 0U};
static unsigned int ng145[] = {2227730452U, 0U};
static unsigned int ng146[] = {59U, 0U};
static unsigned int ng147[] = {2361852424U, 0U};
static unsigned int ng148[] = {60U, 0U};
static unsigned int ng149[] = {2428436474U, 0U};
static unsigned int ng150[] = {61U, 0U};
static unsigned int ng151[] = {2756734187U, 0U};
static unsigned int ng152[] = {62U, 0U};
static unsigned int ng153[] = {3204031479U, 0U};
static unsigned int ng154[] = {63U, 0U};
static unsigned int ng155[] = {3329325298U, 0U};
static int ng156[] = {14, 0};
static int ng157[] = {9, 0};
static int ng158[] = {1, 0};
static int ng159[] = {0, 0};
static int ng160[] = {16, 0};



static void S0_func_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng1, 2, 31, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static void S1_func_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng2, 2, 31, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static void Ch_func_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng3, 2, 31, 0, 0, t10, 0, 1, 0);
    t11 = (t0 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 320U);
    t14 = (t0 + 80U);
    t15 = *((char **)t14);
    xsi_vlogvar_initialize(t13, ng4, 2, 31, 0, 0, t15, 0, 1, 0);
    t16 = (t0 + 96U);
    t17 = *((char **)t16);
    t18 = (t17 + 480U);
    t19 = (t0 + 80U);
    t20 = *((char **)t19);
    xsi_vlogvar_initialize(t18, ng5, 2, 31, 0, 0, t20, 0, 1, 0);

LAB1:    return;
}

static void Maj_func_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng3, 2, 31, 0, 0, t10, 0, 1, 0);
    t11 = (t0 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 320U);
    t14 = (t0 + 80U);
    t15 = *((char **)t14);
    xsi_vlogvar_initialize(t13, ng4, 2, 31, 0, 0, t15, 0, 1, 0);
    t16 = (t0 + 96U);
    t17 = *((char **)t16);
    t18 = (t17 + 480U);
    t19 = (t0 + 80U);
    t20 = *((char **)t19);
    xsi_vlogvar_initialize(t18, ng6, 2, 31, 0, 0, t20, 0, 1, 0);

LAB1:    return;
}

static void ROTR_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng7, 0, 31, 0, 0, t10, 0, 1, 0);
    t11 = (t0 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 320U);
    t14 = (t0 + 80U);
    t15 = *((char **)t14);
    xsi_vlogvar_initialize(t13, ng8, 2, 31, 0, 0, t15, 0, 1, 0);

LAB1:    return;
}

static void sigma0_func_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng9, 2, 31, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static void sigma1_func_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 0U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 31, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 160U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng10, 2, 31, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static int sp_S0_func(char *t1, char *t2)
{
    char t9[8];
    char t16[8];
    char t17[8];
    char t51[8];
    char t58[8];
    char t59[8];
    char t87[8];
    char t107[8];
    char t114[8];
    char t115[8];
    char t143[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;
    char *t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    char *t119;
    char *t120;
    char *t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    char *t147;
    char *t148;
    char *t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    char *t157;
    char *t158;
    char *t159;

LAB0:    t0 = 1;
    xsi_set_current_line(45, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng12)));
    memset(t9, 0, 8);
    xsi_vlog_unsigned_rshift(t9, 32, t7, 32, t8, 32);
    t10 = (t2 + 96U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = ((char*)((ng13)));
    memset(t16, 0, 8);
    xsi_vlog_unsigned_lshift(t16, 32, t14, 32, t15, 32);
    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t16);
    t20 = (t18 | t19);
    *((unsigned int *)t17) = t20;
    t21 = (t9 + 4);
    t22 = (t16 + 4);
    t23 = (t17 + 4);
    t24 = *((unsigned int *)t21);
    t25 = *((unsigned int *)t22);
    t26 = (t24 | t25);
    *((unsigned int *)t23) = t26;
    t27 = *((unsigned int *)t23);
    t28 = (t27 != 0);
    if (t28 == 1)
        goto LAB2;

LAB3:
LAB4:    t45 = (t2 + 96U);
    t46 = *((char **)t45);
    t47 = (t46 + 0U);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    t50 = ((char*)((ng14)));
    memset(t51, 0, 8);
    xsi_vlog_unsigned_rshift(t51, 32, t49, 32, t50, 32);
    t52 = (t2 + 96U);
    t53 = *((char **)t52);
    t54 = (t53 + 0U);
    t55 = (t54 + 56U);
    t56 = *((char **)t55);
    t57 = ((char*)((ng15)));
    memset(t58, 0, 8);
    xsi_vlog_unsigned_lshift(t58, 32, t56, 32, t57, 32);
    t60 = *((unsigned int *)t51);
    t61 = *((unsigned int *)t58);
    t62 = (t60 | t61);
    *((unsigned int *)t59) = t62;
    t63 = (t51 + 4);
    t64 = (t58 + 4);
    t65 = (t59 + 4);
    t66 = *((unsigned int *)t63);
    t67 = *((unsigned int *)t64);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = *((unsigned int *)t65);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB5;

LAB6:
LAB7:    t88 = *((unsigned int *)t17);
    t89 = *((unsigned int *)t59);
    t90 = (t88 ^ t89);
    *((unsigned int *)t87) = t90;
    t91 = (t17 + 4);
    t92 = (t59 + 4);
    t93 = (t87 + 4);
    t94 = *((unsigned int *)t91);
    t95 = *((unsigned int *)t92);
    t96 = (t94 | t95);
    *((unsigned int *)t93) = t96;
    t97 = *((unsigned int *)t93);
    t98 = (t97 != 0);
    if (t98 == 1)
        goto LAB8;

LAB9:
LAB10:    t101 = (t2 + 96U);
    t102 = *((char **)t101);
    t103 = (t102 + 0U);
    t104 = (t103 + 56U);
    t105 = *((char **)t104);
    t106 = ((char*)((ng16)));
    memset(t107, 0, 8);
    xsi_vlog_unsigned_rshift(t107, 32, t105, 32, t106, 32);
    t108 = (t2 + 96U);
    t109 = *((char **)t108);
    t110 = (t109 + 0U);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    t113 = ((char*)((ng17)));
    memset(t114, 0, 8);
    xsi_vlog_unsigned_lshift(t114, 32, t112, 32, t113, 32);
    t116 = *((unsigned int *)t107);
    t117 = *((unsigned int *)t114);
    t118 = (t116 | t117);
    *((unsigned int *)t115) = t118;
    t119 = (t107 + 4);
    t120 = (t114 + 4);
    t121 = (t115 + 4);
    t122 = *((unsigned int *)t119);
    t123 = *((unsigned int *)t120);
    t124 = (t122 | t123);
    *((unsigned int *)t121) = t124;
    t125 = *((unsigned int *)t121);
    t126 = (t125 != 0);
    if (t126 == 1)
        goto LAB11;

LAB12:
LAB13:    t144 = *((unsigned int *)t87);
    t145 = *((unsigned int *)t115);
    t146 = (t144 ^ t145);
    *((unsigned int *)t143) = t146;
    t147 = (t87 + 4);
    t148 = (t115 + 4);
    t149 = (t143 + 4);
    t150 = *((unsigned int *)t147);
    t151 = *((unsigned int *)t148);
    t152 = (t150 | t151);
    *((unsigned int *)t149) = t152;
    t153 = *((unsigned int *)t149);
    t154 = (t153 != 0);
    if (t154 == 1)
        goto LAB14;

LAB15:
LAB16:    t157 = (t2 + 96U);
    t158 = *((char **)t157);
    t159 = (t158 + 160U);
    xsi_vlogvar_assign_value(t159, t143, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB2:    t29 = *((unsigned int *)t17);
    t30 = *((unsigned int *)t23);
    *((unsigned int *)t17) = (t29 | t30);
    t31 = (t9 + 4);
    t32 = (t16 + 4);
    t33 = *((unsigned int *)t31);
    t34 = (~(t33));
    t35 = *((unsigned int *)t9);
    t36 = (t35 & t34);
    t37 = *((unsigned int *)t32);
    t38 = (~(t37));
    t39 = *((unsigned int *)t16);
    t40 = (t39 & t38);
    t41 = (~(t36));
    t42 = (~(t40));
    t43 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t43 & t41);
    t44 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t44 & t42);
    goto LAB4;

LAB5:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t65);
    *((unsigned int *)t59) = (t71 | t72);
    t73 = (t51 + 4);
    t74 = (t58 + 4);
    t75 = *((unsigned int *)t73);
    t76 = (~(t75));
    t77 = *((unsigned int *)t51);
    t78 = (t77 & t76);
    t79 = *((unsigned int *)t74);
    t80 = (~(t79));
    t81 = *((unsigned int *)t58);
    t82 = (t81 & t80);
    t83 = (~(t78));
    t84 = (~(t82));
    t85 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t85 & t83);
    t86 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t86 & t84);
    goto LAB7;

LAB8:    t99 = *((unsigned int *)t87);
    t100 = *((unsigned int *)t93);
    *((unsigned int *)t87) = (t99 | t100);
    goto LAB10;

LAB11:    t127 = *((unsigned int *)t115);
    t128 = *((unsigned int *)t121);
    *((unsigned int *)t115) = (t127 | t128);
    t129 = (t107 + 4);
    t130 = (t114 + 4);
    t131 = *((unsigned int *)t129);
    t132 = (~(t131));
    t133 = *((unsigned int *)t107);
    t134 = (t133 & t132);
    t135 = *((unsigned int *)t130);
    t136 = (~(t135));
    t137 = *((unsigned int *)t114);
    t138 = (t137 & t136);
    t139 = (~(t134));
    t140 = (~(t138));
    t141 = *((unsigned int *)t121);
    *((unsigned int *)t121) = (t141 & t139);
    t142 = *((unsigned int *)t121);
    *((unsigned int *)t121) = (t142 & t140);
    goto LAB13;

LAB14:    t155 = *((unsigned int *)t143);
    t156 = *((unsigned int *)t149);
    *((unsigned int *)t143) = (t155 | t156);
    goto LAB16;

}

static int sp_S1_func(char *t1, char *t2)
{
    char t9[8];
    char t16[8];
    char t17[8];
    char t51[8];
    char t58[8];
    char t59[8];
    char t87[8];
    char t107[8];
    char t114[8];
    char t115[8];
    char t143[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;
    char *t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    char *t119;
    char *t120;
    char *t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    char *t147;
    char *t148;
    char *t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    char *t157;
    char *t158;
    char *t159;

LAB0:    t0 = 1;
    xsi_set_current_line(46, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng18)));
    memset(t9, 0, 8);
    xsi_vlog_unsigned_rshift(t9, 32, t7, 32, t8, 32);
    t10 = (t2 + 96U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = ((char*)((ng19)));
    memset(t16, 0, 8);
    xsi_vlog_unsigned_lshift(t16, 32, t14, 32, t15, 32);
    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t16);
    t20 = (t18 | t19);
    *((unsigned int *)t17) = t20;
    t21 = (t9 + 4);
    t22 = (t16 + 4);
    t23 = (t17 + 4);
    t24 = *((unsigned int *)t21);
    t25 = *((unsigned int *)t22);
    t26 = (t24 | t25);
    *((unsigned int *)t23) = t26;
    t27 = *((unsigned int *)t23);
    t28 = (t27 != 0);
    if (t28 == 1)
        goto LAB2;

LAB3:
LAB4:    t45 = (t2 + 96U);
    t46 = *((char **)t45);
    t47 = (t46 + 0U);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    t50 = ((char*)((ng20)));
    memset(t51, 0, 8);
    xsi_vlog_unsigned_rshift(t51, 32, t49, 32, t50, 32);
    t52 = (t2 + 96U);
    t53 = *((char **)t52);
    t54 = (t53 + 0U);
    t55 = (t54 + 56U);
    t56 = *((char **)t55);
    t57 = ((char*)((ng21)));
    memset(t58, 0, 8);
    xsi_vlog_unsigned_lshift(t58, 32, t56, 32, t57, 32);
    t60 = *((unsigned int *)t51);
    t61 = *((unsigned int *)t58);
    t62 = (t60 | t61);
    *((unsigned int *)t59) = t62;
    t63 = (t51 + 4);
    t64 = (t58 + 4);
    t65 = (t59 + 4);
    t66 = *((unsigned int *)t63);
    t67 = *((unsigned int *)t64);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = *((unsigned int *)t65);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB5;

LAB6:
LAB7:    t88 = *((unsigned int *)t17);
    t89 = *((unsigned int *)t59);
    t90 = (t88 ^ t89);
    *((unsigned int *)t87) = t90;
    t91 = (t17 + 4);
    t92 = (t59 + 4);
    t93 = (t87 + 4);
    t94 = *((unsigned int *)t91);
    t95 = *((unsigned int *)t92);
    t96 = (t94 | t95);
    *((unsigned int *)t93) = t96;
    t97 = *((unsigned int *)t93);
    t98 = (t97 != 0);
    if (t98 == 1)
        goto LAB8;

LAB9:
LAB10:    t101 = (t2 + 96U);
    t102 = *((char **)t101);
    t103 = (t102 + 0U);
    t104 = (t103 + 56U);
    t105 = *((char **)t104);
    t106 = ((char*)((ng22)));
    memset(t107, 0, 8);
    xsi_vlog_unsigned_rshift(t107, 32, t105, 32, t106, 32);
    t108 = (t2 + 96U);
    t109 = *((char **)t108);
    t110 = (t109 + 0U);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    t113 = ((char*)((ng23)));
    memset(t114, 0, 8);
    xsi_vlog_unsigned_lshift(t114, 32, t112, 32, t113, 32);
    t116 = *((unsigned int *)t107);
    t117 = *((unsigned int *)t114);
    t118 = (t116 | t117);
    *((unsigned int *)t115) = t118;
    t119 = (t107 + 4);
    t120 = (t114 + 4);
    t121 = (t115 + 4);
    t122 = *((unsigned int *)t119);
    t123 = *((unsigned int *)t120);
    t124 = (t122 | t123);
    *((unsigned int *)t121) = t124;
    t125 = *((unsigned int *)t121);
    t126 = (t125 != 0);
    if (t126 == 1)
        goto LAB11;

LAB12:
LAB13:    t144 = *((unsigned int *)t87);
    t145 = *((unsigned int *)t115);
    t146 = (t144 ^ t145);
    *((unsigned int *)t143) = t146;
    t147 = (t87 + 4);
    t148 = (t115 + 4);
    t149 = (t143 + 4);
    t150 = *((unsigned int *)t147);
    t151 = *((unsigned int *)t148);
    t152 = (t150 | t151);
    *((unsigned int *)t149) = t152;
    t153 = *((unsigned int *)t149);
    t154 = (t153 != 0);
    if (t154 == 1)
        goto LAB14;

LAB15:
LAB16:    t157 = (t2 + 96U);
    t158 = *((char **)t157);
    t159 = (t158 + 160U);
    xsi_vlogvar_assign_value(t159, t143, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB2:    t29 = *((unsigned int *)t17);
    t30 = *((unsigned int *)t23);
    *((unsigned int *)t17) = (t29 | t30);
    t31 = (t9 + 4);
    t32 = (t16 + 4);
    t33 = *((unsigned int *)t31);
    t34 = (~(t33));
    t35 = *((unsigned int *)t9);
    t36 = (t35 & t34);
    t37 = *((unsigned int *)t32);
    t38 = (~(t37));
    t39 = *((unsigned int *)t16);
    t40 = (t39 & t38);
    t41 = (~(t36));
    t42 = (~(t40));
    t43 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t43 & t41);
    t44 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t44 & t42);
    goto LAB4;

LAB5:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t65);
    *((unsigned int *)t59) = (t71 | t72);
    t73 = (t51 + 4);
    t74 = (t58 + 4);
    t75 = *((unsigned int *)t73);
    t76 = (~(t75));
    t77 = *((unsigned int *)t51);
    t78 = (t77 & t76);
    t79 = *((unsigned int *)t74);
    t80 = (~(t79));
    t81 = *((unsigned int *)t58);
    t82 = (t81 & t80);
    t83 = (~(t78));
    t84 = (~(t82));
    t85 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t85 & t83);
    t86 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t86 & t84);
    goto LAB7;

LAB8:    t99 = *((unsigned int *)t87);
    t100 = *((unsigned int *)t93);
    *((unsigned int *)t87) = (t99 | t100);
    goto LAB10;

LAB11:    t127 = *((unsigned int *)t115);
    t128 = *((unsigned int *)t121);
    *((unsigned int *)t115) = (t127 | t128);
    t129 = (t107 + 4);
    t130 = (t114 + 4);
    t131 = *((unsigned int *)t129);
    t132 = (~(t131));
    t133 = *((unsigned int *)t107);
    t134 = (t133 & t132);
    t135 = *((unsigned int *)t130);
    t136 = (~(t135));
    t137 = *((unsigned int *)t114);
    t138 = (t137 & t136);
    t139 = (~(t134));
    t140 = (~(t138));
    t141 = *((unsigned int *)t121);
    *((unsigned int *)t121) = (t141 & t139);
    t142 = *((unsigned int *)t121);
    *((unsigned int *)t121) = (t142 & t140);
    goto LAB13;

LAB14:    t155 = *((unsigned int *)t143);
    t156 = *((unsigned int *)t149);
    *((unsigned int *)t143) = (t155 | t156);
    goto LAB16;

}

static int sp_Ch_func(char *t1, char *t2)
{
    char t13[8];
    char t45[8];
    char t66[8];
    char t98[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    int t37;
    int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t71;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    char *t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    int t90;
    int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    char *t103;
    char *t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    char *t112;
    char *t113;
    char *t114;

LAB0:    t0 = 1;
    xsi_set_current_line(47, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t2 + 96U);
    t9 = *((char **)t8);
    t10 = (t9 + 160U);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t14 = *((unsigned int *)t7);
    t15 = *((unsigned int *)t12);
    t16 = (t14 & t15);
    *((unsigned int *)t13) = t16;
    t17 = (t7 + 4);
    t18 = (t12 + 4);
    t19 = (t13 + 4);
    t20 = *((unsigned int *)t17);
    t21 = *((unsigned int *)t18);
    t22 = (t20 | t21);
    *((unsigned int *)t19) = t22;
    t23 = *((unsigned int *)t19);
    t24 = (t23 != 0);
    if (t24 == 1)
        goto LAB2;

LAB3:
LAB4:    t46 = (t2 + 96U);
    t47 = *((char **)t46);
    t48 = (t47 + 0U);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    memset(t45, 0, 8);
    t51 = (t45 + 4);
    t52 = (t50 + 4);
    t53 = *((unsigned int *)t50);
    t54 = (~(t53));
    *((unsigned int *)t45) = t54;
    *((unsigned int *)t51) = 0;
    if (*((unsigned int *)t52) != 0)
        goto LAB6;

LAB5:    t59 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t59 & 4294967295U);
    t60 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t60 & 4294967295U);
    t61 = (t2 + 96U);
    t62 = *((char **)t61);
    t63 = (t62 + 320U);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    t67 = *((unsigned int *)t45);
    t68 = *((unsigned int *)t65);
    t69 = (t67 & t68);
    *((unsigned int *)t66) = t69;
    t70 = (t45 + 4);
    t71 = (t65 + 4);
    t72 = (t66 + 4);
    t73 = *((unsigned int *)t70);
    t74 = *((unsigned int *)t71);
    t75 = (t73 | t74);
    *((unsigned int *)t72) = t75;
    t76 = *((unsigned int *)t72);
    t77 = (t76 != 0);
    if (t77 == 1)
        goto LAB7;

LAB8:
LAB9:    t99 = *((unsigned int *)t13);
    t100 = *((unsigned int *)t66);
    t101 = (t99 ^ t100);
    *((unsigned int *)t98) = t101;
    t102 = (t13 + 4);
    t103 = (t66 + 4);
    t104 = (t98 + 4);
    t105 = *((unsigned int *)t102);
    t106 = *((unsigned int *)t103);
    t107 = (t105 | t106);
    *((unsigned int *)t104) = t107;
    t108 = *((unsigned int *)t104);
    t109 = (t108 != 0);
    if (t109 == 1)
        goto LAB10;

LAB11:
LAB12:    t112 = (t2 + 96U);
    t113 = *((char **)t112);
    t114 = (t113 + 480U);
    xsi_vlogvar_assign_value(t114, t98, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB2:    t25 = *((unsigned int *)t13);
    t26 = *((unsigned int *)t19);
    *((unsigned int *)t13) = (t25 | t26);
    t27 = (t7 + 4);
    t28 = (t12 + 4);
    t29 = *((unsigned int *)t7);
    t30 = (~(t29));
    t31 = *((unsigned int *)t27);
    t32 = (~(t31));
    t33 = *((unsigned int *)t12);
    t34 = (~(t33));
    t35 = *((unsigned int *)t28);
    t36 = (~(t35));
    t37 = (t30 & t32);
    t38 = (t34 & t36);
    t39 = (~(t37));
    t40 = (~(t38));
    t41 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t41 & t39);
    t42 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t42 & t40);
    t43 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t43 & t39);
    t44 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t44 & t40);
    goto LAB4;

LAB6:    t55 = *((unsigned int *)t45);
    t56 = *((unsigned int *)t52);
    *((unsigned int *)t45) = (t55 | t56);
    t57 = *((unsigned int *)t51);
    t58 = *((unsigned int *)t52);
    *((unsigned int *)t51) = (t57 | t58);
    goto LAB5;

LAB7:    t78 = *((unsigned int *)t66);
    t79 = *((unsigned int *)t72);
    *((unsigned int *)t66) = (t78 | t79);
    t80 = (t45 + 4);
    t81 = (t65 + 4);
    t82 = *((unsigned int *)t45);
    t83 = (~(t82));
    t84 = *((unsigned int *)t80);
    t85 = (~(t84));
    t86 = *((unsigned int *)t65);
    t87 = (~(t86));
    t88 = *((unsigned int *)t81);
    t89 = (~(t88));
    t90 = (t83 & t85);
    t91 = (t87 & t89);
    t92 = (~(t90));
    t93 = (~(t91));
    t94 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t94 & t92);
    t95 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t95 & t93);
    t96 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t96 & t92);
    t97 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t97 & t93);
    goto LAB9;

LAB10:    t110 = *((unsigned int *)t98);
    t111 = *((unsigned int *)t104);
    *((unsigned int *)t98) = (t110 | t111);
    goto LAB12;

}

static int sp_Maj_func(char *t1, char *t2)
{
    char t13[8];
    char t55[8];
    char t87[8];
    char t111[8];
    char t143[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    int t37;
    int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    char *t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    int t79;
    int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    char *t115;
    char *t116;
    char *t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    char *t125;
    char *t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    int t135;
    int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    char *t147;
    char *t148;
    char *t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    char *t157;
    char *t158;
    char *t159;

LAB0:    t0 = 1;
    xsi_set_current_line(48, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t2 + 96U);
    t9 = *((char **)t8);
    t10 = (t9 + 160U);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t14 = *((unsigned int *)t7);
    t15 = *((unsigned int *)t12);
    t16 = (t14 & t15);
    *((unsigned int *)t13) = t16;
    t17 = (t7 + 4);
    t18 = (t12 + 4);
    t19 = (t13 + 4);
    t20 = *((unsigned int *)t17);
    t21 = *((unsigned int *)t18);
    t22 = (t20 | t21);
    *((unsigned int *)t19) = t22;
    t23 = *((unsigned int *)t19);
    t24 = (t23 != 0);
    if (t24 == 1)
        goto LAB2;

LAB3:
LAB4:    t45 = (t2 + 96U);
    t46 = *((char **)t45);
    t47 = (t46 + 0U);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    t50 = (t2 + 96U);
    t51 = *((char **)t50);
    t52 = (t51 + 320U);
    t53 = (t52 + 56U);
    t54 = *((char **)t53);
    t56 = *((unsigned int *)t49);
    t57 = *((unsigned int *)t54);
    t58 = (t56 & t57);
    *((unsigned int *)t55) = t58;
    t59 = (t49 + 4);
    t60 = (t54 + 4);
    t61 = (t55 + 4);
    t62 = *((unsigned int *)t59);
    t63 = *((unsigned int *)t60);
    t64 = (t62 | t63);
    *((unsigned int *)t61) = t64;
    t65 = *((unsigned int *)t61);
    t66 = (t65 != 0);
    if (t66 == 1)
        goto LAB5;

LAB6:
LAB7:    t88 = *((unsigned int *)t13);
    t89 = *((unsigned int *)t55);
    t90 = (t88 ^ t89);
    *((unsigned int *)t87) = t90;
    t91 = (t13 + 4);
    t92 = (t55 + 4);
    t93 = (t87 + 4);
    t94 = *((unsigned int *)t91);
    t95 = *((unsigned int *)t92);
    t96 = (t94 | t95);
    *((unsigned int *)t93) = t96;
    t97 = *((unsigned int *)t93);
    t98 = (t97 != 0);
    if (t98 == 1)
        goto LAB8;

LAB9:
LAB10:    t101 = (t2 + 96U);
    t102 = *((char **)t101);
    t103 = (t102 + 160U);
    t104 = (t103 + 56U);
    t105 = *((char **)t104);
    t106 = (t2 + 96U);
    t107 = *((char **)t106);
    t108 = (t107 + 320U);
    t109 = (t108 + 56U);
    t110 = *((char **)t109);
    t112 = *((unsigned int *)t105);
    t113 = *((unsigned int *)t110);
    t114 = (t112 & t113);
    *((unsigned int *)t111) = t114;
    t115 = (t105 + 4);
    t116 = (t110 + 4);
    t117 = (t111 + 4);
    t118 = *((unsigned int *)t115);
    t119 = *((unsigned int *)t116);
    t120 = (t118 | t119);
    *((unsigned int *)t117) = t120;
    t121 = *((unsigned int *)t117);
    t122 = (t121 != 0);
    if (t122 == 1)
        goto LAB11;

LAB12:
LAB13:    t144 = *((unsigned int *)t87);
    t145 = *((unsigned int *)t111);
    t146 = (t144 ^ t145);
    *((unsigned int *)t143) = t146;
    t147 = (t87 + 4);
    t148 = (t111 + 4);
    t149 = (t143 + 4);
    t150 = *((unsigned int *)t147);
    t151 = *((unsigned int *)t148);
    t152 = (t150 | t151);
    *((unsigned int *)t149) = t152;
    t153 = *((unsigned int *)t149);
    t154 = (t153 != 0);
    if (t154 == 1)
        goto LAB14;

LAB15:
LAB16:    t157 = (t2 + 96U);
    t158 = *((char **)t157);
    t159 = (t158 + 480U);
    xsi_vlogvar_assign_value(t159, t143, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB2:    t25 = *((unsigned int *)t13);
    t26 = *((unsigned int *)t19);
    *((unsigned int *)t13) = (t25 | t26);
    t27 = (t7 + 4);
    t28 = (t12 + 4);
    t29 = *((unsigned int *)t7);
    t30 = (~(t29));
    t31 = *((unsigned int *)t27);
    t32 = (~(t31));
    t33 = *((unsigned int *)t12);
    t34 = (~(t33));
    t35 = *((unsigned int *)t28);
    t36 = (~(t35));
    t37 = (t30 & t32);
    t38 = (t34 & t36);
    t39 = (~(t37));
    t40 = (~(t38));
    t41 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t41 & t39);
    t42 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t42 & t40);
    t43 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t43 & t39);
    t44 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t44 & t40);
    goto LAB4;

LAB5:    t67 = *((unsigned int *)t55);
    t68 = *((unsigned int *)t61);
    *((unsigned int *)t55) = (t67 | t68);
    t69 = (t49 + 4);
    t70 = (t54 + 4);
    t71 = *((unsigned int *)t49);
    t72 = (~(t71));
    t73 = *((unsigned int *)t69);
    t74 = (~(t73));
    t75 = *((unsigned int *)t54);
    t76 = (~(t75));
    t77 = *((unsigned int *)t70);
    t78 = (~(t77));
    t79 = (t72 & t74);
    t80 = (t76 & t78);
    t81 = (~(t79));
    t82 = (~(t80));
    t83 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t83 & t81);
    t84 = *((unsigned int *)t61);
    *((unsigned int *)t61) = (t84 & t82);
    t85 = *((unsigned int *)t55);
    *((unsigned int *)t55) = (t85 & t81);
    t86 = *((unsigned int *)t55);
    *((unsigned int *)t55) = (t86 & t82);
    goto LAB7;

LAB8:    t99 = *((unsigned int *)t87);
    t100 = *((unsigned int *)t93);
    *((unsigned int *)t87) = (t99 | t100);
    goto LAB10;

LAB11:    t123 = *((unsigned int *)t111);
    t124 = *((unsigned int *)t117);
    *((unsigned int *)t111) = (t123 | t124);
    t125 = (t105 + 4);
    t126 = (t110 + 4);
    t127 = *((unsigned int *)t105);
    t128 = (~(t127));
    t129 = *((unsigned int *)t125);
    t130 = (~(t129));
    t131 = *((unsigned int *)t110);
    t132 = (~(t131));
    t133 = *((unsigned int *)t126);
    t134 = (~(t133));
    t135 = (t128 & t130);
    t136 = (t132 & t134);
    t137 = (~(t135));
    t138 = (~(t136));
    t139 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t139 & t137);
    t140 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t140 & t138);
    t141 = *((unsigned int *)t111);
    *((unsigned int *)t111) = (t141 & t137);
    t142 = *((unsigned int *)t111);
    *((unsigned int *)t111) = (t142 & t138);
    goto LAB13;

LAB14:    t155 = *((unsigned int *)t143);
    t156 = *((unsigned int *)t149);
    *((unsigned int *)t143) = (t155 | t156);
    goto LAB16;

}

static int sp_ROTR(char *t1, char *t2)
{
    char t13[8];
    char t25[8];
    char t26[8];
    char t27[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;

LAB0:    t0 = 1;
    xsi_set_current_line(49, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t2 + 96U);
    t9 = *((char **)t8);
    t10 = (t9 + 160U);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memset(t13, 0, 8);
    xsi_vlog_unsigned_rshift(t13, 32, t7, 32, t12, 32);
    t14 = (t2 + 96U);
    t15 = *((char **)t14);
    t16 = (t15 + 0U);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = ((char*)((ng24)));
    t20 = (t2 + 96U);
    t21 = *((char **)t20);
    t22 = (t21 + 160U);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memset(t25, 0, 8);
    xsi_vlog_signed_minus(t25, 32, t19, 32, t24, 32);
    memset(t26, 0, 8);
    xsi_vlog_unsigned_lshift(t26, 32, t18, 32, t25, 32);
    t28 = *((unsigned int *)t13);
    t29 = *((unsigned int *)t26);
    t30 = (t28 | t29);
    *((unsigned int *)t27) = t30;
    t31 = (t13 + 4);
    t32 = (t26 + 4);
    t33 = (t27 + 4);
    t34 = *((unsigned int *)t31);
    t35 = *((unsigned int *)t32);
    t36 = (t34 | t35);
    *((unsigned int *)t33) = t36;
    t37 = *((unsigned int *)t33);
    t38 = (t37 != 0);
    if (t38 == 1)
        goto LAB2;

LAB3:
LAB4:    t55 = (t2 + 96U);
    t56 = *((char **)t55);
    t57 = (t56 + 320U);
    xsi_vlogvar_assign_value(t57, t27, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB2:    t39 = *((unsigned int *)t27);
    t40 = *((unsigned int *)t33);
    *((unsigned int *)t27) = (t39 | t40);
    t41 = (t13 + 4);
    t42 = (t26 + 4);
    t43 = *((unsigned int *)t41);
    t44 = (~(t43));
    t45 = *((unsigned int *)t13);
    t46 = (t45 & t44);
    t47 = *((unsigned int *)t42);
    t48 = (~(t47));
    t49 = *((unsigned int *)t26);
    t50 = (t49 & t48);
    t51 = (~(t46));
    t52 = (~(t50));
    t53 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t53 & t51);
    t54 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t54 & t52);
    goto LAB4;

}

static int sp_sigma0_func(char *t1, char *t2)
{
    char t33[8];
    char t67[8];
    char t71[8];
    char t91[8];
    char t92[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    int t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t68;
    char *t69;
    char *t70;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t75;
    char *t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    char *t108;

LAB0:    t0 = 1;
    xsi_set_current_line(50, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng23)));
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    t11 = (t1 + 2712);
    t12 = xsi_create_subprogram_invocation(t10, 0, t1, t11, 0, t2);
    t13 = (t12 + 96U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    xsi_vlogvar_assign_value(t15, t7, 0, 0, 32);
    t16 = (t12 + 96U);
    t17 = *((char **)t16);
    t18 = (t17 + 160U);
    xsi_vlogvar_assign_value(t18, t8, 0, 0, 32);

LAB2:    t19 = (t2 + 64U);
    t20 = *((char **)t19);
    t21 = (t20 + 80U);
    t22 = *((char **)t21);
    t23 = (t22 + 272U);
    t24 = *((char **)t23);
    t25 = (t24 + 0U);
    t26 = *((char **)t25);
    t27 = ((int  (*)(char *, char *))t26)(t1, t20);
    if (t27 != 0)
        goto LAB4;

LAB3:    t20 = (t2 + 64U);
    t28 = *((char **)t20);
    t20 = (t28 + 96U);
    t29 = *((char **)t20);
    t30 = (t29 + 320U);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t33, t32, 8);
    t34 = (t1 + 2712);
    t35 = (t2 + 56U);
    t36 = *((char **)t35);
    xsi_delete_subprogram_invocation(t34, t28, t1, t36, t2);
    t37 = (t2 + 96U);
    t38 = *((char **)t37);
    t39 = (t38 + 0U);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    t42 = ((char*)((ng25)));
    t43 = (t2 + 56U);
    t44 = *((char **)t43);
    t45 = (t1 + 2712);
    t46 = xsi_create_subprogram_invocation(t44, 0, t1, t45, 0, t2);
    t47 = (t46 + 96U);
    t48 = *((char **)t47);
    t49 = (t48 + 0U);
    xsi_vlogvar_assign_value(t49, t41, 0, 0, 32);
    t50 = (t46 + 96U);
    t51 = *((char **)t50);
    t52 = (t51 + 160U);
    xsi_vlogvar_assign_value(t52, t42, 0, 0, 32);

LAB5:    t53 = (t2 + 64U);
    t54 = *((char **)t53);
    t55 = (t54 + 80U);
    t56 = *((char **)t55);
    t57 = (t56 + 272U);
    t58 = *((char **)t57);
    t59 = (t58 + 0U);
    t60 = *((char **)t59);
    t61 = ((int  (*)(char *, char *))t60)(t1, t54);
    if (t61 != 0)
        goto LAB7;

LAB6:    t54 = (t2 + 64U);
    t62 = *((char **)t54);
    t54 = (t62 + 96U);
    t63 = *((char **)t54);
    t64 = (t63 + 320U);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    memcpy(t67, t66, 8);
    t68 = (t1 + 2712);
    t69 = (t2 + 56U);
    t70 = *((char **)t69);
    xsi_delete_subprogram_invocation(t68, t62, t1, t70, t2);
    t72 = *((unsigned int *)t33);
    t73 = *((unsigned int *)t67);
    t74 = (t72 ^ t73);
    *((unsigned int *)t71) = t74;
    t75 = (t33 + 4);
    t76 = (t67 + 4);
    t77 = (t71 + 4);
    t78 = *((unsigned int *)t75);
    t79 = *((unsigned int *)t76);
    t80 = (t78 | t79);
    *((unsigned int *)t77) = t80;
    t81 = *((unsigned int *)t77);
    t82 = (t81 != 0);
    if (t82 == 1)
        goto LAB8;

LAB9:
LAB10:    t85 = (t2 + 96U);
    t86 = *((char **)t85);
    t87 = (t86 + 0U);
    t88 = (t87 + 56U);
    t89 = *((char **)t88);
    t90 = ((char*)((ng26)));
    memset(t91, 0, 8);
    xsi_vlog_unsigned_rshift(t91, 32, t89, 32, t90, 32);
    t93 = *((unsigned int *)t71);
    t94 = *((unsigned int *)t91);
    t95 = (t93 ^ t94);
    *((unsigned int *)t92) = t95;
    t96 = (t71 + 4);
    t97 = (t91 + 4);
    t98 = (t92 + 4);
    t99 = *((unsigned int *)t96);
    t100 = *((unsigned int *)t97);
    t101 = (t99 | t100);
    *((unsigned int *)t98) = t101;
    t102 = *((unsigned int *)t98);
    t103 = (t102 != 0);
    if (t103 == 1)
        goto LAB11;

LAB12:
LAB13:    t106 = (t2 + 96U);
    t107 = *((char **)t106);
    t108 = (t107 + 160U);
    xsi_vlogvar_assign_value(t108, t92, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB4:    t19 = (t2 + 48U);
    *((char **)t19) = &&LAB2;
    goto LAB1;

LAB7:    t53 = (t2 + 48U);
    *((char **)t53) = &&LAB5;
    goto LAB1;

LAB8:    t83 = *((unsigned int *)t71);
    t84 = *((unsigned int *)t77);
    *((unsigned int *)t71) = (t83 | t84);
    goto LAB10;

LAB11:    t104 = *((unsigned int *)t92);
    t105 = *((unsigned int *)t98);
    *((unsigned int *)t92) = (t104 | t105);
    goto LAB13;

}

static int sp_sigma1_func(char *t1, char *t2)
{
    char t33[8];
    char t67[8];
    char t71[8];
    char t91[8];
    char t92[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    int t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t68;
    char *t69;
    char *t70;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t75;
    char *t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    char *t108;

LAB0:    t0 = 1;
    xsi_set_current_line(51, ng11);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 0U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng27)));
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    t11 = (t1 + 2712);
    t12 = xsi_create_subprogram_invocation(t10, 0, t1, t11, 0, t2);
    t13 = (t12 + 96U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    xsi_vlogvar_assign_value(t15, t7, 0, 0, 32);
    t16 = (t12 + 96U);
    t17 = *((char **)t16);
    t18 = (t17 + 160U);
    xsi_vlogvar_assign_value(t18, t8, 0, 0, 32);

LAB2:    t19 = (t2 + 64U);
    t20 = *((char **)t19);
    t21 = (t20 + 80U);
    t22 = *((char **)t21);
    t23 = (t22 + 272U);
    t24 = *((char **)t23);
    t25 = (t24 + 0U);
    t26 = *((char **)t25);
    t27 = ((int  (*)(char *, char *))t26)(t1, t20);
    if (t27 != 0)
        goto LAB4;

LAB3:    t20 = (t2 + 64U);
    t28 = *((char **)t20);
    t20 = (t28 + 96U);
    t29 = *((char **)t20);
    t30 = (t29 + 320U);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    memcpy(t33, t32, 8);
    t34 = (t1 + 2712);
    t35 = (t2 + 56U);
    t36 = *((char **)t35);
    xsi_delete_subprogram_invocation(t34, t28, t1, t36, t2);
    t37 = (t2 + 96U);
    t38 = *((char **)t37);
    t39 = (t38 + 0U);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    t42 = ((char*)((ng15)));
    t43 = (t2 + 56U);
    t44 = *((char **)t43);
    t45 = (t1 + 2712);
    t46 = xsi_create_subprogram_invocation(t44, 0, t1, t45, 0, t2);
    t47 = (t46 + 96U);
    t48 = *((char **)t47);
    t49 = (t48 + 0U);
    xsi_vlogvar_assign_value(t49, t41, 0, 0, 32);
    t50 = (t46 + 96U);
    t51 = *((char **)t50);
    t52 = (t51 + 160U);
    xsi_vlogvar_assign_value(t52, t42, 0, 0, 32);

LAB5:    t53 = (t2 + 64U);
    t54 = *((char **)t53);
    t55 = (t54 + 80U);
    t56 = *((char **)t55);
    t57 = (t56 + 272U);
    t58 = *((char **)t57);
    t59 = (t58 + 0U);
    t60 = *((char **)t59);
    t61 = ((int  (*)(char *, char *))t60)(t1, t54);
    if (t61 != 0)
        goto LAB7;

LAB6:    t54 = (t2 + 64U);
    t62 = *((char **)t54);
    t54 = (t62 + 96U);
    t63 = *((char **)t54);
    t64 = (t63 + 320U);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    memcpy(t67, t66, 8);
    t68 = (t1 + 2712);
    t69 = (t2 + 56U);
    t70 = *((char **)t69);
    xsi_delete_subprogram_invocation(t68, t62, t1, t70, t2);
    t72 = *((unsigned int *)t33);
    t73 = *((unsigned int *)t67);
    t74 = (t72 ^ t73);
    *((unsigned int *)t71) = t74;
    t75 = (t33 + 4);
    t76 = (t67 + 4);
    t77 = (t71 + 4);
    t78 = *((unsigned int *)t75);
    t79 = *((unsigned int *)t76);
    t80 = (t78 | t79);
    *((unsigned int *)t77) = t80;
    t81 = *((unsigned int *)t77);
    t82 = (t81 != 0);
    if (t82 == 1)
        goto LAB8;

LAB9:
LAB10:    t85 = (t2 + 96U);
    t86 = *((char **)t85);
    t87 = (t86 + 0U);
    t88 = (t87 + 56U);
    t89 = *((char **)t88);
    t90 = ((char*)((ng17)));
    memset(t91, 0, 8);
    xsi_vlog_unsigned_rshift(t91, 32, t89, 32, t90, 32);
    t93 = *((unsigned int *)t71);
    t94 = *((unsigned int *)t91);
    t95 = (t93 ^ t94);
    *((unsigned int *)t92) = t95;
    t96 = (t71 + 4);
    t97 = (t91 + 4);
    t98 = (t92 + 4);
    t99 = *((unsigned int *)t96);
    t100 = *((unsigned int *)t97);
    t101 = (t99 | t100);
    *((unsigned int *)t98) = t101;
    t102 = *((unsigned int *)t98);
    t103 = (t102 != 0);
    if (t103 == 1)
        goto LAB11;

LAB12:
LAB13:    t106 = (t2 + 96U);
    t107 = *((char **)t106);
    t108 = (t107 + 160U);
    xsi_vlogvar_assign_value(t108, t92, 0, 0, 32);
    t0 = 0;

LAB1:    return t0;
LAB4:    t19 = (t2 + 48U);
    *((char **)t19) = &&LAB2;
    goto LAB1;

LAB7:    t53 = (t2 + 48U);
    *((char **)t53) = &&LAB5;
    goto LAB1;

LAB8:    t83 = *((unsigned int *)t71);
    t84 = *((unsigned int *)t77);
    *((unsigned int *)t71) = (t83 | t84);
    goto LAB10;

LAB11:    t104 = *((unsigned int *)t92);
    t105 = *((unsigned int *)t98);
    *((unsigned int *)t92) = (t104 | t105);
    goto LAB13;

}

static void Cont_57_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 11288U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(57, ng11);
    t2 = (t0 + 10048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 18552);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 18056);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Always_59_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 11536U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(59, ng11);
    t2 = (t0 + 18072);
    *((int *)t2) = 1;
    t3 = (t0 + 11568);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(59, ng11);

LAB5:    xsi_set_current_line(60, ng11);
    t4 = (t0 + 5488U);
    t5 = *((char **)t4);

LAB6:    t4 = ((char*)((ng28)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t4, 6);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng30)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng32)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng34)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng36)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng38)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng40)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng42)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng44)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng46)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng48)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng50)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng52)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng54)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng56)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB35;

LAB36:    t2 = ((char*)((ng58)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB37;

LAB38:    t2 = ((char*)((ng60)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB39;

LAB40:    t2 = ((char*)((ng62)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB41;

LAB42:    t2 = ((char*)((ng64)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB43;

LAB44:    t2 = ((char*)((ng66)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB45;

LAB46:    t2 = ((char*)((ng68)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB47;

LAB48:    t2 = ((char*)((ng70)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB49;

LAB50:    t2 = ((char*)((ng72)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB51;

LAB52:    t2 = ((char*)((ng74)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB53;

LAB54:    t2 = ((char*)((ng76)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB55;

LAB56:    t2 = ((char*)((ng78)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB57;

LAB58:    t2 = ((char*)((ng80)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB59;

LAB60:    t2 = ((char*)((ng82)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB61;

LAB62:    t2 = ((char*)((ng84)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB63;

LAB64:    t2 = ((char*)((ng86)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB65;

LAB66:    t2 = ((char*)((ng88)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB67;

LAB68:    t2 = ((char*)((ng90)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB69;

LAB70:    t2 = ((char*)((ng92)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB71;

LAB72:    t2 = ((char*)((ng94)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB73;

LAB74:    t2 = ((char*)((ng96)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB75;

LAB76:    t2 = ((char*)((ng98)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB77;

LAB78:    t2 = ((char*)((ng100)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB79;

LAB80:    t2 = ((char*)((ng102)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB81;

LAB82:    t2 = ((char*)((ng104)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB83;

LAB84:    t2 = ((char*)((ng106)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB85;

LAB86:    t2 = ((char*)((ng108)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB87;

LAB88:    t2 = ((char*)((ng110)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB89;

LAB90:    t2 = ((char*)((ng112)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB91;

LAB92:    t2 = ((char*)((ng114)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB93;

LAB94:    t2 = ((char*)((ng116)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB95;

LAB96:    t2 = ((char*)((ng118)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB97;

LAB98:    t2 = ((char*)((ng120)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB99;

LAB100:    t2 = ((char*)((ng122)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB101;

LAB102:    t2 = ((char*)((ng124)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB103;

LAB104:    t2 = ((char*)((ng126)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB105;

LAB106:    t2 = ((char*)((ng128)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB107;

LAB108:    t2 = ((char*)((ng130)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB109;

LAB110:    t2 = ((char*)((ng132)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB111;

LAB112:    t2 = ((char*)((ng134)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB113;

LAB114:    t2 = ((char*)((ng136)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB115;

LAB116:    t2 = ((char*)((ng138)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB117;

LAB118:    t2 = ((char*)((ng140)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB119;

LAB120:    t2 = ((char*)((ng142)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB121;

LAB122:    t2 = ((char*)((ng144)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB123;

LAB124:    t2 = ((char*)((ng146)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB125;

LAB126:    t2 = ((char*)((ng148)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB127;

LAB128:    t2 = ((char*)((ng150)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB129;

LAB130:    t2 = ((char*)((ng152)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB131;

LAB132:    t2 = ((char*)((ng154)));
    t6 = xsi_vlog_unsigned_case_compare(t5, 6, t2, 6);
    if (t6 == 1)
        goto LAB133;

LAB134:
LAB136:
LAB135:    xsi_set_current_line(93, ng11);
    t2 = ((char*)((ng28)));
    t3 = (t0 + 10048);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB137:    goto LAB2;

LAB7:    xsi_set_current_line(61, ng11);
    t7 = ((char*)((ng29)));
    t8 = (t0 + 10048);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 32);
    goto LAB137;

LAB9:    xsi_set_current_line(61, ng11);
    t3 = ((char*)((ng31)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB11:    xsi_set_current_line(62, ng11);
    t3 = ((char*)((ng33)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB13:    xsi_set_current_line(62, ng11);
    t3 = ((char*)((ng35)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB15:    xsi_set_current_line(63, ng11);
    t3 = ((char*)((ng37)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB17:    xsi_set_current_line(63, ng11);
    t3 = ((char*)((ng39)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB19:    xsi_set_current_line(64, ng11);
    t3 = ((char*)((ng41)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB21:    xsi_set_current_line(64, ng11);
    t3 = ((char*)((ng43)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB23:    xsi_set_current_line(65, ng11);
    t3 = ((char*)((ng45)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB25:    xsi_set_current_line(65, ng11);
    t3 = ((char*)((ng47)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB27:    xsi_set_current_line(66, ng11);
    t3 = ((char*)((ng49)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB29:    xsi_set_current_line(66, ng11);
    t3 = ((char*)((ng51)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB31:    xsi_set_current_line(67, ng11);
    t3 = ((char*)((ng53)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB33:    xsi_set_current_line(67, ng11);
    t3 = ((char*)((ng55)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB35:    xsi_set_current_line(68, ng11);
    t3 = ((char*)((ng57)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB37:    xsi_set_current_line(68, ng11);
    t3 = ((char*)((ng59)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB39:    xsi_set_current_line(69, ng11);
    t3 = ((char*)((ng61)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB41:    xsi_set_current_line(69, ng11);
    t3 = ((char*)((ng63)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB43:    xsi_set_current_line(70, ng11);
    t3 = ((char*)((ng65)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB45:    xsi_set_current_line(70, ng11);
    t3 = ((char*)((ng67)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB47:    xsi_set_current_line(71, ng11);
    t3 = ((char*)((ng69)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB49:    xsi_set_current_line(71, ng11);
    t3 = ((char*)((ng71)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB51:    xsi_set_current_line(72, ng11);
    t3 = ((char*)((ng73)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB53:    xsi_set_current_line(72, ng11);
    t3 = ((char*)((ng75)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB55:    xsi_set_current_line(73, ng11);
    t3 = ((char*)((ng77)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB57:    xsi_set_current_line(73, ng11);
    t3 = ((char*)((ng79)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB59:    xsi_set_current_line(74, ng11);
    t3 = ((char*)((ng81)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB61:    xsi_set_current_line(74, ng11);
    t3 = ((char*)((ng83)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB63:    xsi_set_current_line(75, ng11);
    t3 = ((char*)((ng85)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB65:    xsi_set_current_line(75, ng11);
    t3 = ((char*)((ng87)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB67:    xsi_set_current_line(76, ng11);
    t3 = ((char*)((ng89)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB69:    xsi_set_current_line(76, ng11);
    t3 = ((char*)((ng91)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB71:    xsi_set_current_line(77, ng11);
    t3 = ((char*)((ng93)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB73:    xsi_set_current_line(77, ng11);
    t3 = ((char*)((ng95)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB75:    xsi_set_current_line(78, ng11);
    t3 = ((char*)((ng97)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB77:    xsi_set_current_line(78, ng11);
    t3 = ((char*)((ng99)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB79:    xsi_set_current_line(79, ng11);
    t3 = ((char*)((ng101)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB81:    xsi_set_current_line(79, ng11);
    t3 = ((char*)((ng103)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB83:    xsi_set_current_line(80, ng11);
    t3 = ((char*)((ng105)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB85:    xsi_set_current_line(80, ng11);
    t3 = ((char*)((ng107)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB87:    xsi_set_current_line(81, ng11);
    t3 = ((char*)((ng109)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB89:    xsi_set_current_line(81, ng11);
    t3 = ((char*)((ng111)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB91:    xsi_set_current_line(82, ng11);
    t3 = ((char*)((ng113)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB93:    xsi_set_current_line(82, ng11);
    t3 = ((char*)((ng115)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB95:    xsi_set_current_line(83, ng11);
    t3 = ((char*)((ng117)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB97:    xsi_set_current_line(83, ng11);
    t3 = ((char*)((ng119)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB99:    xsi_set_current_line(84, ng11);
    t3 = ((char*)((ng121)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB101:    xsi_set_current_line(84, ng11);
    t3 = ((char*)((ng123)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB103:    xsi_set_current_line(85, ng11);
    t3 = ((char*)((ng125)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB105:    xsi_set_current_line(85, ng11);
    t3 = ((char*)((ng127)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB107:    xsi_set_current_line(86, ng11);
    t3 = ((char*)((ng129)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB109:    xsi_set_current_line(86, ng11);
    t3 = ((char*)((ng131)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB111:    xsi_set_current_line(87, ng11);
    t3 = ((char*)((ng133)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB113:    xsi_set_current_line(87, ng11);
    t3 = ((char*)((ng135)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB115:    xsi_set_current_line(88, ng11);
    t3 = ((char*)((ng137)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB117:    xsi_set_current_line(88, ng11);
    t3 = ((char*)((ng139)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB119:    xsi_set_current_line(89, ng11);
    t3 = ((char*)((ng141)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB121:    xsi_set_current_line(89, ng11);
    t3 = ((char*)((ng143)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB123:    xsi_set_current_line(90, ng11);
    t3 = ((char*)((ng145)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB125:    xsi_set_current_line(90, ng11);
    t3 = ((char*)((ng147)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB127:    xsi_set_current_line(91, ng11);
    t3 = ((char*)((ng149)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB129:    xsi_set_current_line(91, ng11);
    t3 = ((char*)((ng151)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB131:    xsi_set_current_line(92, ng11);
    t3 = ((char*)((ng153)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

LAB133:    xsi_set_current_line(92, ng11);
    t3 = ((char*)((ng155)));
    t4 = (t0 + 10048);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);
    goto LAB137;

}

static void Cont_107_2(char *t0)
{
    char t23[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    t1 = (t0 + 11784U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(107, ng11);
    t2 = (t0 + 8048U);
    t3 = *((char **)t2);
    t2 = (t0 + 11592);
    t4 = (t0 + 3144);
    t5 = xsi_create_subprogram_invocation(t2, 0, t0, t4, 0, 0);
    t6 = (t5 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    xsi_vlogvar_assign_value(t8, t3, 0, 0, 32);

LAB4:    t9 = (t0 + 11688);
    t10 = *((char **)t9);
    t11 = (t10 + 80U);
    t12 = *((char **)t11);
    t13 = (t12 + 272U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    t16 = *((char **)t15);
    t17 = ((int  (*)(char *, char *))t16)(t0, t10);
    if (t17 != 0)
        goto LAB6;

LAB5:    t10 = (t0 + 11688);
    t18 = *((char **)t10);
    t10 = (t18 + 96U);
    t19 = *((char **)t10);
    t20 = (t19 + 160U);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t23, t22, 8);
    t24 = (t0 + 3144);
    t25 = (t0 + 11592);
    t26 = 0;
    xsi_delete_subprogram_invocation(t24, t18, t0, t25, t26);
    t27 = (t0 + 18616);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t23, 8);
    xsi_driver_vfirst_trans(t27, 0, 31);
    t32 = (t0 + 18088);
    *((int *)t32) = 1;

LAB1:    return;
LAB6:    t9 = (t0 + 11784U);
    *((char **)t9) = &&LAB4;
    goto LAB1;

}

static void Cont_108_3(char *t0)
{
    char t23[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    t1 = (t0 + 12032U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(108, ng11);
    t2 = (t0 + 7728U);
    t3 = *((char **)t2);
    t2 = (t0 + 11840);
    t4 = (t0 + 3576);
    t5 = xsi_create_subprogram_invocation(t2, 0, t0, t4, 0, 0);
    t6 = (t5 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    xsi_vlogvar_assign_value(t8, t3, 0, 0, 32);

LAB4:    t9 = (t0 + 11936);
    t10 = *((char **)t9);
    t11 = (t10 + 80U);
    t12 = *((char **)t11);
    t13 = (t12 + 272U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    t16 = *((char **)t15);
    t17 = ((int  (*)(char *, char *))t16)(t0, t10);
    if (t17 != 0)
        goto LAB6;

LAB5:    t10 = (t0 + 11936);
    t18 = *((char **)t10);
    t10 = (t18 + 96U);
    t19 = *((char **)t10);
    t20 = (t19 + 160U);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t23, t22, 8);
    t24 = (t0 + 3576);
    t25 = (t0 + 11840);
    t26 = 0;
    xsi_delete_subprogram_invocation(t24, t18, t0, t25, t26);
    t27 = (t0 + 18680);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t23, 8);
    xsi_driver_vfirst_trans(t27, 0, 31);
    t32 = (t0 + 18104);
    *((int *)t32) = 1;

LAB1:    return;
LAB6:    t9 = (t0 + 12032U);
    *((char **)t9) = &&LAB4;
    goto LAB1;

}

static void Cont_110_4(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 12280U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(110, ng11);
    t2 = (t0 + 10208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = (t0 + 10208);
    t7 = (t6 + 72U);
    t8 = *((char **)t7);
    t9 = (t0 + 10208);
    t10 = (t9 + 64U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng156)));
    xsi_vlog_generic_get_array_select_value(t5, 32, t4, t8, t11, 2, 1, t12, 32, 1);
    t13 = (t0 + 18744);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8);
    xsi_driver_vfirst_trans(t13, 0, 31);
    t18 = (t0 + 18120);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_111_5(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 12528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(111, ng11);
    t2 = (t0 + 10208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = (t0 + 10208);
    t7 = (t6 + 72U);
    t8 = *((char **)t7);
    t9 = (t0 + 10208);
    t10 = (t9 + 64U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng157)));
    xsi_vlog_generic_get_array_select_value(t5, 32, t4, t8, t11, 2, 1, t12, 32, 1);
    t13 = (t0 + 18808);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8);
    xsi_driver_vfirst_trans(t13, 0, 31);
    t18 = (t0 + 18136);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_112_6(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 12776U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(112, ng11);
    t2 = (t0 + 10208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = (t0 + 10208);
    t7 = (t6 + 72U);
    t8 = *((char **)t7);
    t9 = (t0 + 10208);
    t10 = (t9 + 64U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng158)));
    xsi_vlog_generic_get_array_select_value(t5, 32, t4, t8, t11, 2, 1, t12, 32, 1);
    t13 = (t0 + 18872);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8);
    xsi_driver_vfirst_trans(t13, 0, 31);
    t18 = (t0 + 18152);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_113_7(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 13024U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(113, ng11);
    t2 = (t0 + 10208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = (t0 + 10208);
    t7 = (t6 + 72U);
    t8 = *((char **)t7);
    t9 = (t0 + 10208);
    t10 = (t9 + 64U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng159)));
    xsi_vlog_generic_get_array_select_value(t5, 32, t4, t8, t11, 2, 1, t12, 32, 1);
    t13 = (t0 + 18936);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8);
    xsi_driver_vfirst_trans(t13, 0, 31);
    t18 = (t0 + 18168);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_115_8(char *t0)
{
    char t5[8];
    char t7[8];
    char t9[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    t1 = (t0 + 13272U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(115, ng11);
    t2 = (t0 + 8528U);
    t3 = *((char **)t2);
    t2 = (t0 + 7888U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 8368U);
    t6 = *((char **)t2);
    memset(t7, 0, 8);
    xsi_vlog_unsigned_add(t7, 32, t5, 32, t6, 32);
    t2 = (t0 + 8208U);
    t8 = *((char **)t2);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 32, t7, 32, t8, 32);
    t2 = (t0 + 19000);
    t10 = (t2 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t9, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t14 = (t0 + 18184);
    *((int *)t14) = 1;

LAB1:    return;
}

static void Always_117_9(char *t0)
{
    char t4[8];
    char t16[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    int t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;

LAB0:    t1 = (t0 + 13520U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(117, ng11);
    t2 = (t0 + 18200);
    *((int *)t2) = 1;
    t3 = (t0 + 13552);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(117, ng11);

LAB5:    xsi_set_current_line(118, ng11);
    t5 = (t0 + 5488U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t4 + 4);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t4) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t5) = t11;
    t12 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t12 & 15U);
    t13 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t13 & 15U);

LAB6:    t14 = ((char*)((ng28)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t14, 4);
    if (t15 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng30)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng32)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng34)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng36)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng38)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng40)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng42)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng44)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng46)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng48)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng50)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng52)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng54)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng56)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB35;

LAB36:    t2 = ((char*)((ng58)));
    t15 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t15 == 1)
        goto LAB37;

LAB38:
LAB40:
LAB39:    xsi_set_current_line(135, ng11);
    t2 = ((char*)((ng28)));
    t3 = (t0 + 10368);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB41:    goto LAB2;

LAB7:    xsi_set_current_line(119, ng11);
    t17 = (t0 + 5648U);
    t18 = *((char **)t17);
    memset(t16, 0, 8);
    t17 = (t16 + 4);
    t19 = (t18 + 120);
    t20 = (t18 + 124);
    t21 = *((unsigned int *)t19);
    t22 = (t21 >> 0);
    *((unsigned int *)t16) = t22;
    t23 = *((unsigned int *)t20);
    t24 = (t23 >> 0);
    *((unsigned int *)t17) = t24;
    t25 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t25 & 4294967295U);
    t26 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t26 & 4294967295U);
    t27 = (t0 + 10368);
    xsi_vlogvar_assign_value(t27, t16, 0, 0, 32);
    goto LAB41;

LAB9:    xsi_set_current_line(120, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 112);
    t7 = (t5 + 116);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB11:    xsi_set_current_line(121, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 104);
    t7 = (t5 + 108);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB13:    xsi_set_current_line(122, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 96);
    t7 = (t5 + 100);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB15:    xsi_set_current_line(123, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 88);
    t7 = (t5 + 92);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB17:    xsi_set_current_line(124, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 80);
    t7 = (t5 + 84);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB19:    xsi_set_current_line(125, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 72);
    t7 = (t5 + 76);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB21:    xsi_set_current_line(126, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 64);
    t7 = (t5 + 68);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB23:    xsi_set_current_line(127, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 56);
    t7 = (t5 + 60);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB25:    xsi_set_current_line(128, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 48);
    t7 = (t5 + 52);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB27:    xsi_set_current_line(129, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 40);
    t7 = (t5 + 44);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB29:    xsi_set_current_line(130, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 32);
    t7 = (t5 + 36);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB31:    xsi_set_current_line(131, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 24);
    t7 = (t5 + 28);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB33:    xsi_set_current_line(132, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 16);
    t7 = (t5 + 20);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB35:    xsi_set_current_line(133, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 8);
    t7 = (t5 + 12);
    t8 = *((unsigned int *)t6);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t14 = (t0 + 10368);
    xsi_vlogvar_assign_value(t14, t16, 0, 0, 32);
    goto LAB41;

LAB37:    xsi_set_current_line(134, ng11);
    t3 = (t0 + 5648U);
    t5 = *((char **)t3);
    memset(t16, 0, 8);
    t3 = (t16 + 4);
    t6 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 0);
    *((unsigned int *)t16) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 0);
    *((unsigned int *)t3) = t11;
    t12 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t13 & 4294967295U);
    t7 = (t0 + 10368);
    xsi_vlogvar_assign_value(t7, t16, 0, 0, 32);
    goto LAB41;

}

static void Cont_139_10(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    t1 = (t0 + 13768U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(139, ng11);
    t2 = (t0 + 5488U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng160)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB5;

LAB4:    t8 = (t2 + 4);
    if (*((unsigned int *)t8) != 0)
        goto LAB5;

LAB8:    if (*((unsigned int *)t5) < *((unsigned int *)t2))
        goto LAB6;

LAB7:    memset(t4, 0, 8);
    t10 = (t6 + 4);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t6);
    t14 = (t13 & t12);
    t15 = (t14 & 1U);
    if (t15 != 0)
        goto LAB9;

LAB10:    if (*((unsigned int *)t10) != 0)
        goto LAB11;

LAB12:    t17 = (t4 + 4);
    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t17);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB13;

LAB14:    t24 = *((unsigned int *)t4);
    t25 = (~(t24));
    t26 = *((unsigned int *)t17);
    t27 = (t25 || t26);
    if (t27 > 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t17) > 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t4) > 0)
        goto LAB19;

LAB20:    memcpy(t3, t29, 8);

LAB21:    t28 = (t0 + 19064);
    t30 = (t28 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    memcpy(t33, t3, 8);
    xsi_driver_vfirst_trans(t28, 0, 31);
    t34 = (t0 + 18216);
    *((int *)t34) = 1;

LAB1:    return;
LAB5:    t9 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t6) = 1;
    goto LAB7;

LAB9:    *((unsigned int *)t4) = 1;
    goto LAB12;

LAB11:    t16 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB12;

LAB13:    t21 = (t0 + 10368);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    goto LAB14;

LAB15:    t28 = (t0 + 8688U);
    t29 = *((char **)t28);
    goto LAB16;

LAB17:    xsi_vlog_unsigned_bit_combine(t3, 32, t23, 32, t29, 32);
    goto LAB21;

LAB19:    memcpy(t3, t23, 8);
    goto LAB21;

}

static void Cont_150_11(char *t0)
{
    char t31[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;

LAB0:    t1 = (t0 + 14016U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(150, ng11);
    t2 = (t0 + 4848U);
    t3 = *((char **)t2);
    t2 = (t0 + 5008U);
    t4 = *((char **)t2);
    t2 = (t0 + 5168U);
    t5 = *((char **)t2);
    t2 = (t0 + 13824);
    t6 = (t0 + 1848);
    t7 = xsi_create_subprogram_invocation(t2, 0, t0, t6, 0, 0);
    t8 = (t7 + 96U);
    t9 = *((char **)t8);
    t10 = (t9 + 0U);
    xsi_vlogvar_assign_value(t10, t3, 0, 0, 32);
    t11 = (t7 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 160U);
    xsi_vlogvar_assign_value(t13, t4, 0, 0, 32);
    t14 = (t7 + 96U);
    t15 = *((char **)t14);
    t16 = (t15 + 320U);
    xsi_vlogvar_assign_value(t16, t5, 0, 0, 32);

LAB4:    t17 = (t0 + 13920);
    t18 = *((char **)t17);
    t19 = (t18 + 80U);
    t20 = *((char **)t19);
    t21 = (t20 + 272U);
    t22 = *((char **)t21);
    t23 = (t22 + 0U);
    t24 = *((char **)t23);
    t25 = ((int  (*)(char *, char *))t24)(t0, t18);
    if (t25 != 0)
        goto LAB6;

LAB5:    t18 = (t0 + 13920);
    t26 = *((char **)t18);
    t18 = (t26 + 96U);
    t27 = *((char **)t18);
    t28 = (t27 + 480U);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    memcpy(t31, t30, 8);
    t32 = (t0 + 1848);
    t33 = (t0 + 13824);
    t34 = 0;
    xsi_delete_subprogram_invocation(t32, t26, t0, t33, t34);
    t35 = (t0 + 19128);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t31, 8);
    xsi_driver_vfirst_trans(t35, 0, 31);
    t40 = (t0 + 18232);
    *((int *)t40) = 1;

LAB1:    return;
LAB6:    t17 = (t0 + 14016U);
    *((char **)t17) = &&LAB4;
    goto LAB1;

}

static void Cont_151_12(char *t0)
{
    char t31[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;

LAB0:    t1 = (t0 + 14264U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(151, ng11);
    t2 = (t0 + 4208U);
    t3 = *((char **)t2);
    t2 = (t0 + 4368U);
    t4 = *((char **)t2);
    t2 = (t0 + 4528U);
    t5 = *((char **)t2);
    t2 = (t0 + 14072);
    t6 = (t0 + 2280);
    t7 = xsi_create_subprogram_invocation(t2, 0, t0, t6, 0, 0);
    t8 = (t7 + 96U);
    t9 = *((char **)t8);
    t10 = (t9 + 0U);
    xsi_vlogvar_assign_value(t10, t3, 0, 0, 32);
    t11 = (t7 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 160U);
    xsi_vlogvar_assign_value(t13, t4, 0, 0, 32);
    t14 = (t7 + 96U);
    t15 = *((char **)t14);
    t16 = (t15 + 320U);
    xsi_vlogvar_assign_value(t16, t5, 0, 0, 32);

LAB4:    t17 = (t0 + 14168);
    t18 = *((char **)t17);
    t19 = (t18 + 80U);
    t20 = *((char **)t19);
    t21 = (t20 + 272U);
    t22 = *((char **)t21);
    t23 = (t22 + 0U);
    t24 = *((char **)t23);
    t25 = ((int  (*)(char *, char *))t24)(t0, t18);
    if (t25 != 0)
        goto LAB6;

LAB5:    t18 = (t0 + 14168);
    t26 = *((char **)t18);
    t18 = (t26 + 96U);
    t27 = *((char **)t18);
    t28 = (t27 + 480U);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    memcpy(t31, t30, 8);
    t32 = (t0 + 2280);
    t33 = (t0 + 14072);
    t34 = 0;
    xsi_delete_subprogram_invocation(t32, t26, t0, t33, t34);
    t35 = (t0 + 19192);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t31, 8);
    xsi_driver_vfirst_trans(t35, 0, 31);
    t40 = (t0 + 18248);
    *((int *)t40) = 1;

LAB1:    return;
LAB6:    t17 = (t0 + 14264U);
    *((char **)t17) = &&LAB4;
    goto LAB1;

}

static void Cont_152_13(char *t0)
{
    char t23[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    t1 = (t0 + 14512U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(152, ng11);
    t2 = (t0 + 4208U);
    t3 = *((char **)t2);
    t2 = (t0 + 14320);
    t4 = (t0 + 984);
    t5 = xsi_create_subprogram_invocation(t2, 0, t0, t4, 0, 0);
    t6 = (t5 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    xsi_vlogvar_assign_value(t8, t3, 0, 0, 32);

LAB4:    t9 = (t0 + 14416);
    t10 = *((char **)t9);
    t11 = (t10 + 80U);
    t12 = *((char **)t11);
    t13 = (t12 + 272U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    t16 = *((char **)t15);
    t17 = ((int  (*)(char *, char *))t16)(t0, t10);
    if (t17 != 0)
        goto LAB6;

LAB5:    t10 = (t0 + 14416);
    t18 = *((char **)t10);
    t10 = (t18 + 96U);
    t19 = *((char **)t10);
    t20 = (t19 + 160U);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t23, t22, 8);
    t24 = (t0 + 984);
    t25 = (t0 + 14320);
    t26 = 0;
    xsi_delete_subprogram_invocation(t24, t18, t0, t25, t26);
    t27 = (t0 + 19256);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t23, 8);
    xsi_driver_vfirst_trans(t27, 0, 31);
    t32 = (t0 + 18264);
    *((int *)t32) = 1;

LAB1:    return;
LAB6:    t9 = (t0 + 14512U);
    *((char **)t9) = &&LAB4;
    goto LAB1;

}

static void Cont_153_14(char *t0)
{
    char t23[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    t1 = (t0 + 14760U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(153, ng11);
    t2 = (t0 + 4848U);
    t3 = *((char **)t2);
    t2 = (t0 + 14568);
    t4 = (t0 + 1416);
    t5 = xsi_create_subprogram_invocation(t2, 0, t0, t4, 0, 0);
    t6 = (t5 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    xsi_vlogvar_assign_value(t8, t3, 0, 0, 32);

LAB4:    t9 = (t0 + 14664);
    t10 = *((char **)t9);
    t11 = (t10 + 80U);
    t12 = *((char **)t11);
    t13 = (t12 + 272U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    t16 = *((char **)t15);
    t17 = ((int  (*)(char *, char *))t16)(t0, t10);
    if (t17 != 0)
        goto LAB6;

LAB5:    t10 = (t0 + 14664);
    t18 = *((char **)t10);
    t10 = (t18 + 96U);
    t19 = *((char **)t10);
    t20 = (t19 + 160U);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t23, t22, 8);
    t24 = (t0 + 1416);
    t25 = (t0 + 14568);
    t26 = 0;
    xsi_delete_subprogram_invocation(t24, t18, t0, t25, t26);
    t27 = (t0 + 19320);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t23, 8);
    xsi_driver_vfirst_trans(t27, 0, 31);
    t32 = (t0 + 18280);
    *((int *)t32) = 1;

LAB1:    return;
LAB6:    t9 = (t0 + 14760U);
    *((char **)t9) = &&LAB4;
    goto LAB1;

}

static void Cont_156_15(char *t0)
{
    char t5[8];
    char t7[8];
    char t9[8];
    char t11[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t8;
    char *t10;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 15008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(156, ng11);
    t2 = (t0 + 5328U);
    t3 = *((char **)t2);
    t2 = (t0 + 9648U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 9168U);
    t6 = *((char **)t2);
    memset(t7, 0, 8);
    xsi_vlog_unsigned_add(t7, 32, t5, 32, t6, 32);
    t2 = (t0 + 7568U);
    t8 = *((char **)t2);
    memset(t9, 0, 8);
    xsi_vlog_unsigned_add(t9, 32, t7, 32, t8, 32);
    t2 = (t0 + 7408U);
    t10 = *((char **)t2);
    memset(t11, 0, 8);
    xsi_vlog_unsigned_add(t11, 32, t9, 32, t10, 32);
    t2 = (t0 + 19384);
    t12 = (t2 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t16 = (t0 + 18296);
    *((int *)t16) = 1;

LAB1:    return;
}

static void Cont_157_16(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 15256U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(157, ng11);
    t2 = (t0 + 9488U);
    t3 = *((char **)t2);
    t2 = (t0 + 9328U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 19448);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t10 = (t0 + 18312);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_160_17(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 15504U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(160, ng11);
    t2 = (t0 + 8848U);
    t3 = *((char **)t2);
    t2 = (t0 + 9008U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 19512);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t10 = (t0 + 18328);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_161_18(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 15752U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(161, ng11);
    t2 = (t0 + 4208U);
    t3 = *((char **)t2);
    t2 = (t0 + 19576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18344);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_162_19(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 16000U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(162, ng11);
    t2 = (t0 + 4368U);
    t3 = *((char **)t2);
    t2 = (t0 + 19640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18360);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_163_20(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 16248U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(163, ng11);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t2 = (t0 + 19704);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18376);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_164_21(char *t0)
{
    char t5[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 16496U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(164, ng11);
    t2 = (t0 + 4688U);
    t3 = *((char **)t2);
    t2 = (t0 + 8848U);
    t4 = *((char **)t2);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t3, 32, t4, 32);
    t2 = (t0 + 19768);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t10 = (t0 + 18392);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_165_22(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 16744U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(165, ng11);
    t2 = (t0 + 4848U);
    t3 = *((char **)t2);
    t2 = (t0 + 19832);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18408);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_166_23(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 16992U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(166, ng11);
    t2 = (t0 + 5008U);
    t3 = *((char **)t2);
    t2 = (t0 + 19896);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18424);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_167_24(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 17240U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(167, ng11);
    t2 = (t0 + 5168U);
    t3 = *((char **)t2);
    t2 = (t0 + 19960);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18440);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_170_25(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 17488U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(170, ng11);
    t2 = (t0 + 8848U);
    t3 = *((char **)t2);
    t2 = (t0 + 20024);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18456);
    *((int *)t8) = 1;

LAB1:    return;
}

static void Cont_171_26(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t1 = (t0 + 17736U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(171, ng11);
    t2 = (t0 + 9008U);
    t3 = *((char **)t2);
    t2 = (t0 + 20088);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8);
    xsi_driver_vfirst_trans(t2, 0, 31);
    t8 = (t0 + 18472);
    *((int *)t8) = 1;

LAB1:    return;
}


extern void work_m_00000000003123604548_1467796507_init()
{
	static char *pe[] = {(void *)Cont_57_0,(void *)Always_59_1,(void *)Cont_107_2,(void *)Cont_108_3,(void *)Cont_110_4,(void *)Cont_111_5,(void *)Cont_112_6,(void *)Cont_113_7,(void *)Cont_115_8,(void *)Always_117_9,(void *)Cont_139_10,(void *)Cont_150_11,(void *)Cont_151_12,(void *)Cont_152_13,(void *)Cont_153_14,(void *)Cont_156_15,(void *)Cont_157_16,(void *)Cont_160_17,(void *)Cont_161_18,(void *)Cont_162_19,(void *)Cont_163_20,(void *)Cont_164_21,(void *)Cont_165_22,(void *)Cont_166_23,(void *)Cont_167_24,(void *)Cont_170_25,(void *)Cont_171_26};
	static char *se[] = {(void *)sp_S0_func,(void *)sp_S1_func,(void *)sp_Ch_func,(void *)sp_Maj_func,(void *)sp_ROTR,(void *)sp_sigma0_func,(void *)sp_sigma1_func};
	xsi_register_didat("work_m_00000000003123604548_1467796507", "isim/tb_sha256_comb_full_isim_beh.exe.sim/work/m_00000000003123604548_1467796507.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
	xsi_register_subprogram_init(1, (void *)S0_func_varinit);
	xsi_register_subprogram_init(2, (void *)S1_func_varinit);
	xsi_register_subprogram_init(3, (void *)Ch_func_varinit);
	xsi_register_subprogram_init(4, (void *)Maj_func_varinit);
	xsi_register_subprogram_init(5, (void *)ROTR_varinit);
	xsi_register_subprogram_init(6, (void *)sigma0_func_varinit);
	xsi_register_subprogram_init(7, (void *)sigma1_func_varinit);
}
