/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "[%0t ns] State: %s, j: %2d, a=%h, b=%h, e=%h, f=%h";
static const char *ng1 = "D:/SHA/CODE/SHA_256_VER_2/SHA_256_VER_2/SHA_256_VER_2/tb_sha256_core.v";
static const char *ng2 = "sha256_waveform.vcd";
static int ng3[] = {0, 0};
static unsigned int ng4[] = {1U, 0U};
static int ng5[] = {1229212741, 0, 0, 0};
static unsigned int ng6[] = {2U, 0U};
static int ng7[] = {1229867348, 0, 0, 0};
static unsigned int ng8[] = {4U, 0U};
static int ng9[] = {1380275027, 0, 1129270608, 0};
static unsigned int ng10[] = {8U, 0U};
static int ng11[] = {1313428296, 0, 17993, 0};
static int ng12[] = {1313822542, 0, 5590603, 0};
static const char *ng13 = "===============================================";
static const char *ng14 = "= Bat dau Testbench cho sha256_core (abc) =";
static int ng15[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
static const char *ng16 = "[%0t ns] Nha reset...";
static int ng17[] = {1, 0};
static const char *ng18 = "[%0t ns] DUT da san sang (o_done = 1).";
static const char *ng19 = "[%0t ns] Cung cap du lieu 'abc' va kich hoat i_write.";
static unsigned int ng20[] = {24U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 1633837952U, 0U};
static const char *ng21 = "[%0t ns] Dang doi o_done... (qua trinh bam dang dien ra)";
static const char *ng22 = "[%0t ns] Qua trinh bam hoan tat! (o_done = 1).";
static const char *ng23 = "-----------------------------------------------";
static const char *ng24 = "KET QUA MONG DOI : %h";
static unsigned int ng25[] = {4060091821U, 0U, 3021012833U, 0U, 2518121116U, 0U, 2953011619U, 0U, 1571693091U, 0U, 1094795486U, 0U, 2399260650U, 0U, 3128432319U, 0U};
static const char *ng26 = "KET QUA THUC TE  : %h";
static const char *ng27 = "***********************************************";
static const char *ng28 = "****** TEST PASSED!            ******";
static const char *ng29 = "****** TEST FAILED!            ******";

void Monitor_70_4(char *);
void Monitor_70_4(char *);


static void Monitor_70_4_Func(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    t2 = xsi_vlog_time(t1, 1000.0000000000000, 1000.0000000000000);
    t3 = (t0 + 3224);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t0 + 8164);
    t7 = *((char **)t6);
    t8 = ((((char*)(t7))) + 56U);
    t9 = *((char **)t8);
    t10 = (t0 + 8180);
    t11 = *((char **)t10);
    t12 = ((((char*)(t11))) + 56U);
    t13 = *((char **)t12);
    t14 = (t0 + 8196);
    t15 = *((char **)t14);
    t16 = ((((char*)(t15))) + 56U);
    t17 = *((char **)t16);
    t18 = (t0 + 8212);
    t19 = *((char **)t18);
    t20 = ((((char*)(t19))) + 56U);
    t21 = *((char **)t20);
    t22 = (t0 + 8228);
    t23 = *((char **)t22);
    t24 = ((((char*)(t23))) + 56U);
    t25 = *((char **)t24);
    xsi_vlogfile_write(1, 0, 3, ng0, 8, t0, (char)118, t1, 64, (char)118, t5, 64, (char)118, t9, 6, (char)118, t13, 32, (char)118, t17, 32, (char)118, t21, 32, (char)118, t25, 32);

LAB1:    return;
}

static void Always_46_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 4144U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(46, ng1);
    t2 = (t0 + 3952);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(46, ng1);
    t4 = (t0 + 2424);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB10;

LAB9:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 2424);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

LAB10:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB9;

}

static void Initial_49_1(char *t0)
{
    char *t1;

LAB0:    xsi_set_current_line(49, ng1);

LAB2:    xsi_set_current_line(50, ng1);
    xsi_vcd_dumpfile(ng2);
    xsi_set_current_line(52, ng1);
    t1 = ((char*)((ng3)));
    xsi_vcd_dumpvars_args(*((unsigned int *)t1), t0, (char)109, t0, (char)101);

LAB1:    return;
}

static void Always_57_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 4640U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(57, ng1);
    t2 = (t0 + 5704);
    *((int *)t2) = 1;
    t3 = (t0 + 4672);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(57, ng1);

LAB5:    xsi_set_current_line(58, ng1);
    t4 = (t0 + 8252);
    t5 = *((char **)t4);
    t6 = ((((char*)(t5))) + 56U);
    t7 = *((char **)t6);

LAB6:    t8 = ((char*)((ng4)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t8, 4);
    if (t9 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng6)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t2, 4);
    if (t9 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t2, 4);
    if (t9 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng10)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t2, 4);
    if (t9 == 1)
        goto LAB13;

LAB14:
LAB16:
LAB15:    xsi_set_current_line(63, ng1);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 3224);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 64);

LAB17:    goto LAB2;

LAB7:    xsi_set_current_line(59, ng1);
    t10 = ((char*)((ng5)));
    t11 = (t0 + 3224);
    xsi_vlogvar_assign_value(t11, t10, 0, 0, 64);
    goto LAB17;

LAB9:    xsi_set_current_line(60, ng1);
    t3 = ((char*)((ng7)));
    t4 = (t0 + 3224);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    goto LAB17;

LAB11:    xsi_set_current_line(61, ng1);
    t3 = ((char*)((ng9)));
    t4 = (t0 + 3224);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    goto LAB17;

LAB13:    xsi_set_current_line(62, ng1);
    t3 = ((char*)((ng11)));
    t4 = (t0 + 3224);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 64);
    goto LAB17;

}

static void Initial_68_3(char *t0)
{

LAB0:    xsi_set_current_line(68, ng1);

LAB2:    xsi_set_current_line(70, ng1);
    Monitor_70_4(t0);

LAB1:    return;
}

static void Initial_75_5(char *t0)
{
    char t4[16];
    char t8[8];
    char t33[64];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    char *t32;

LAB0:    t1 = (t0 + 5136U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(75, ng1);

LAB4:    xsi_set_current_line(76, ng1);
    xsi_vlogfile_write(1, 0, 0, ng13, 1, t0);
    xsi_set_current_line(77, ng1);
    xsi_vlogfile_write(1, 0, 0, ng14, 1, t0);
    xsi_set_current_line(78, ng1);
    xsi_vlogfile_write(1, 0, 0, ng13, 1, t0);
    xsi_set_current_line(81, ng1);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2424);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(82, ng1);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2584);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(83, ng1);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2744);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(84, ng1);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 2904);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 512, 0LL);
    xsi_set_current_line(85, ng1);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3064);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(86, ng1);
    t2 = (t0 + 4944);
    xsi_process_wait(t2, 50000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(89, ng1);
    t2 = xsi_vlog_time(t4, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng16, 2, t0, (char)118, t4, 64);
    xsi_set_current_line(90, ng1);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 2584);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(93, ng1);

LAB6:    t2 = (t0 + 8276);
    t3 = *((char **)t2);
    t5 = ((((char*)(t3))) + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng17)));
    memset(t8, 0, 8);
    t9 = (t6 + 4);
    t10 = (t7 + 4);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t9);
    t15 = *((unsigned int *)t10);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t10);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB10;

LAB7:    if (t20 != 0)
        goto LAB9;

LAB8:    *((unsigned int *)t8) = 1;

LAB10:    t24 = (t8 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB12;

LAB11:    t30 = (t0 + 5720);
    *((int *)t30) = 1;
    t31 = (t0 + 5136U);
    *((char **)t31) = &&LAB6;
    goto LAB1;

LAB9:    t23 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB10;

LAB12:    t32 = (t0 + 5720);
    *((int *)t32) = 0;
    xsi_set_current_line(94, ng1);
    t2 = xsi_vlog_time(t4, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng18, 2, t0, (char)118, t4, 64);
    xsi_set_current_line(97, ng1);
    t2 = xsi_vlog_time(t4, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng19, 2, t0, (char)118, t4, 64);
    xsi_set_current_line(98, ng1);
    t2 = (t0 + 5736);
    *((int *)t2) = 1;
    t3 = (t0 + 5168);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(99, ng1);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 3064);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(100, ng1);
    t2 = ((char*)((ng20)));
    t3 = (t0 + 2904);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 512, 0LL);
    xsi_set_current_line(101, ng1);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 2744);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(103, ng1);
    t2 = (t0 + 5752);
    *((int *)t2) = 1;
    t3 = (t0 + 5168);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(104, ng1);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2744);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(105, ng1);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 2904);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 512, 0LL);
    xsi_set_current_line(106, ng1);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3064);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(109, ng1);
    t2 = xsi_vlog_time(t4, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng21, 2, t0, (char)118, t4, 64);
    xsi_set_current_line(110, ng1);

LAB15:    t2 = (t0 + 1864U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng17)));
    memset(t8, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t11 = *((unsigned int *)t3);
    t12 = *((unsigned int *)t2);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t5);
    t19 = *((unsigned int *)t6);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB19;

LAB16:    if (t20 != 0)
        goto LAB18;

LAB17:    *((unsigned int *)t8) = 1;

LAB19:    t9 = (t8 + 4);
    t25 = *((unsigned int *)t9);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB21;

LAB20:    t10 = (t0 + 5768);
    *((int *)t10) = 1;
    t23 = (t0 + 5136U);
    *((char **)t23) = &&LAB15;
    goto LAB1;

LAB18:    t7 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB19;

LAB21:    t24 = (t0 + 5768);
    *((int *)t24) = 0;
    xsi_set_current_line(111, ng1);
    t2 = xsi_vlog_time(t4, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(1, 0, 0, ng22, 2, t0, (char)118, t4, 64);
    xsi_set_current_line(112, ng1);
    t2 = (t0 + 4944);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB22;
    goto LAB1;

LAB22:    xsi_set_current_line(115, ng1);
    xsi_vlogfile_write(1, 0, 0, ng23, 1, t0);
    xsi_set_current_line(116, ng1);
    t2 = ((char*)((ng25)));
    xsi_vlogfile_write(1, 0, 0, ng24, 2, t0, (char)118, t2, 256);
    xsi_set_current_line(117, ng1);
    t2 = (t0 + 2024U);
    t3 = *((char **)t2);
    xsi_vlogfile_write(1, 0, 0, ng26, 2, t0, (char)118, t3, 256);
    xsi_set_current_line(118, ng1);
    xsi_vlogfile_write(1, 0, 0, ng23, 1, t0);
    xsi_set_current_line(120, ng1);
    t2 = (t0 + 2024U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng25)));
    xsi_vlog_unsigned_equal(t33, 256, t3, 256, t2, 256);
    t5 = (t33 + 4);
    t11 = *((unsigned int *)t5);
    t12 = (~(t11));
    t13 = *((unsigned int *)t33);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB23;

LAB24:    xsi_set_current_line(124, ng1);

LAB27:    xsi_set_current_line(125, ng1);
    xsi_vlogfile_write(1, 0, 0, ng27, 1, t0);
    xsi_set_current_line(126, ng1);
    xsi_vlogfile_write(1, 0, 0, ng29, 1, t0);
    xsi_set_current_line(127, ng1);
    xsi_vlogfile_write(1, 0, 0, ng27, 1, t0);

LAB25:    xsi_set_current_line(131, ng1);
    t2 = (t0 + 4944);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB28;
    goto LAB1;

LAB23:    xsi_set_current_line(120, ng1);

LAB26:    xsi_set_current_line(121, ng1);
    xsi_vlogfile_write(1, 0, 0, ng27, 1, t0);
    xsi_set_current_line(122, ng1);
    xsi_vlogfile_write(1, 0, 0, ng28, 1, t0);
    xsi_set_current_line(123, ng1);
    xsi_vlogfile_write(1, 0, 0, ng27, 1, t0);
    goto LAB25;

LAB28:    xsi_set_current_line(132, ng1);
    xsi_vlog_finish(1);
    goto LAB1;

}

void Monitor_70_4(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 5192);
    t2 = (t0 + 5784);
    xsi_vlogfile_monitor((void *)Monitor_70_4_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000003426827458_3924434475_init()
{
	static char *pe[] = {(void *)Always_46_0,(void *)Initial_49_1,(void *)Always_57_2,(void *)Initial_68_3,(void *)Initial_75_5,(void *)Monitor_70_4};
	xsi_register_didat("work_m_00000000003426827458_3924434475", "isim/tb_sha256_core_isim_beh.exe.sim/work/m_00000000003426827458_3924434475.didat");
	xsi_register_executes(pe);
}
